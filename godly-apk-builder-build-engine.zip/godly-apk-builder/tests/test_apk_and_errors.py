import os
import struct
import tempfile
import time
import unittest
import zipfile
from pathlib import Path

import helpers
from errors import EngineError, ErrorCode, STRUCTURE_HINT
import apk_validator as av
import error_analyzer as ea
import logger


class ApkTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())

    def write(self, name, data):
        p = self.tmp / name; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(data); return p

    def code_of(self, path):
        with self.assertRaises(EngineError) as ctx:
            av.validate_apk(path)
        self.assertEqual(ctx.exception.code, ErrorCode.APK_VALIDATION_ERROR)

    def test_axml_parse(self):
        info = av.parse_manifest_axml(helpers.build_axml("com.godly.demo", 42, "9.9", True))
        self.assertEqual(info, {"package": "com.godly.demo", "versionCode": 42, "versionName": "9.9", "debuggable": True})
        self.assertEqual(av.parse_manifest_axml(b"garbage"), {})
        self.assertEqual(av.parse_manifest_axml(helpers.build_axml()[:40]), {})  # cắt cụt: không ném lỗi

    def test_valid_signed_apk(self):
        r = av.validate_apk(self.write("a.apk", helpers.make_apk_bytes(package="com.x.y", version_code=3, version_name="1.0")))
        self.assertEqual((r.package_name, r.version_code, r.version_name, r.debuggable), ("com.x.y", 3, "1.0", False))
        self.assertTrue(r.signature_present and r.has_classes_dex)
        self.assertEqual(len(r.sha256), 64)
        self.assertEqual(r.warnings, [])

    def test_unsigned_apk_warns_but_is_structurally_valid(self):
        r = av.validate_apk(self.write("a.apk", helpers.make_apk_bytes(signed=False)))
        self.assertFalse(r.signature_present)
        self.assertTrue(any("chưa được ký" in w for w in r.warnings))

    def test_v2_signature_block_detected(self):
        data = bytearray(helpers.make_apk_bytes(signed=False))
        eocd = data.rindex(b"PK\x05\x06")
        cd = struct.unpack_from("<I", data, eocd + 16)[0]
        block = b"\x00" * 8 + b"APK Sig Block 42"
        data[eocd + 16:eocd + 20] = struct.pack("<I", cd + len(block))
        data[cd:cd] = block
        p = self.write("v2.apk", bytes(data))
        self.assertTrue(av.validate_apk(p).signature_present)

    def test_invalid_apks(self):
        self.code_of(self.tmp / "missing.apk")
        self.code_of(self.write("empty.apk", b""))
        self.code_of(self.write("notzip.apk", b"hello" * 100))
        self.code_of(self.write("nomanifest.apk", helpers.make_apk_bytes(manifest=False)))

    def test_corrupt_apk_crc(self):
        p = self.tmp / "c.apk"
        with zipfile.ZipFile(p, "w", zipfile.ZIP_STORED) as z:
            z.writestr("AndroidManifest.xml", helpers.build_axml())
            z.writestr("classes.dex", b"A" * 100 + b"MARKER" + b"B" * 100)
        raw = bytearray(p.read_bytes()); raw[raw.index(b"MARKER")] ^= 0xFF; p.write_bytes(raw)
        self.code_of(p)

    def test_find_and_select(self):
        root = self.tmp / "proj"
        old = self.write("proj/app/build/outputs/apk/debug/old.apk", helpers.make_apk_bytes())
        os.utime(old, (1, 1))
        self.write("proj/app/build/outputs/apk/debug/app-arm64-v8a-debug.apk", helpers.make_apk_bytes())
        self.write("proj/app/build/outputs/apk/debug/app-universal-debug.apk", helpers.make_apk_bytes())
        self.write("proj/app/build/outputs/apk/release/app-release-unsigned.apk", helpers.make_apk_bytes())
        self.write("proj/app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk", helpers.make_apk_bytes())
        self.write("proj/elsewhere/random.apk", helpers.make_apk_bytes())
        every = av.find_apk_candidates(root)
        self.assertEqual(len(every), 4)  # bỏ androidTest và APK ngoài build/outputs/apk
        fresh = av.find_apk_candidates(root, since_ts=time.time() - 60)
        self.assertNotIn(old, fresh)
        sel = av.select_apk(fresh, "debug")
        self.assertTrue(sel.ambiguous)
        self.assertEqual(sel.chosen.name, "app-universal-debug.apk")
        rel = av.select_apk(fresh, "release")
        self.assertFalse(rel.ambiguous)
        self.assertEqual(rel.chosen.name, "app-release-unsigned.apk")
        self.assertIsNone(av.select_apk(fresh[:1], "release").chosen)


class AnalyzerTests(unittest.TestCase):
    def analyze(self, text, prefixes=()):
        return ea.analyze_gradle_log(text.strip().splitlines(), strip_prefixes=prefixes)

    def test_kotlin_error_has_real_file_line_both_formats(self):
        r = self.analyze("e: file:///w/proj/app/src/main/java/com/x/Main.kt:12:34 Unresolved reference: foo", ["/w/proj"])
        self.assertEqual((r.code, r.file, r.line), ("KOTLIN_COMPILATION_ERROR", "app/src/main/java/com/x/Main.kt", 12))
        self.assertEqual(r.cause, "Unresolved reference: foo")
        r = self.analyze("e: /w/proj/app/src/Main.kt: (7, 3): Type mismatch", ["/w/proj"])
        self.assertEqual((r.code, r.file, r.line), ("KOTLIN_COMPILATION_ERROR", "app/src/Main.kt", 7))

    def test_kotlin_error_in_gradle_script_is_configuration_error(self):
        r = self.analyze("e: file:///w/proj/app/build.gradle.kts:20:5 Unresolved reference: foo", ["/w/proj"])
        self.assertEqual((r.code, r.file, r.line), ("GRADLE_CONFIGURATION_ERROR", "app/build.gradle.kts", 20))

    def test_java_error(self):
        r = self.analyze("/w/proj/app/src/main/java/A.java:30: error: cannot find symbol\n  symbol: variable x", ["/w/proj"])
        self.assertEqual((r.code, r.file, r.line), ("JAVA_COMPILATION_ERROR", "app/src/main/java/A.java", 30))

    def test_manifest_and_resource_errors(self):
        r = self.analyze("Manifest merger failed with multiple errors\n/w/app/src/main/AndroidManifest.xml:5:9-12:20 Error: x")
        self.assertEqual((r.code, r.line), ("MANIFEST_ERROR", 5))
        r = self.analyze("ERROR: /w/app/src/main/res/layout/a.xml:10: AAPT: error: resource drawable/x not found.")
        self.assertEqual((r.code, r.line), ("RESOURCE_ERROR", 10))
        self.assertTrue(r.file.endswith("res/layout/a.xml"))

    def test_environment_errors(self):
        cases = {
            "JDK_ERROR": "Unsupported class file major version 65",
            "ANDROID_SDK_ERROR": "SDK location not found. Define a valid SDK location",
            "GRADLE_WRAPPER_MISSING": "./gradlew: not found",
        }
        for code, line in cases.items():
            with self.subTest(code=code):
                self.assertEqual(self.analyze(line).code, code)

    def test_network_vs_dependency(self):
        r = self.analyze("Could not GET 'https://x/y.pom'.\nCaused by: java.net.UnknownHostException: x")
        self.assertEqual(r.code, "NETWORK_ERROR"); self.assertTrue(r.retryable)
        r = self.analyze("Could not find com.foo:bar:1.2.3.")
        self.assertEqual(r.code, "DEPENDENCY_DOWNLOAD_ERROR")
        self.assertIsNone(r.file); self.assertIsNone(r.line)

    def test_groovy_config_error_takes_file_line_from_log(self):
        r = self.analyze("A problem occurred evaluating project ':app'.\n"
                         "Build file '/w/proj/app/build.gradle' line: 14\n> Could not find method foo()", ["/w/proj"])
        self.assertEqual((r.code, r.file, r.line), ("GRADLE_CONFIGURATION_ERROR", "app/build.gradle", 14))

    def test_unknown_is_honest_and_does_not_invent_details(self):
        r = self.analyze("* What went wrong:\nSomething strange\n* Try:\nrun with --stacktrace")
        self.assertEqual(r.code, "UNKNOWN_BUILD_ERROR")
        self.assertEqual(r.cause, ea.UNDETERMINED)
        self.assertFalse(r.confident)
        self.assertIsNone(r.file); self.assertIsNone(r.line)
        self.assertEqual(r.excerpt, ["Something strange"])

    def test_report_excerpts_are_redacted(self):
        r = self.analyze("Could not find com.a:b:1\nexport GITHUB_TOKEN=ghp_abcdefghijklmnopqrstuvwxyz0123456789ABCD")
        self.assertNotIn("ghp_", " ".join(r.excerpt))

    def test_engine_error_mapping_and_special_reports(self):
        e = EngineError(ErrorCode.PROJECT_NOT_FOUND, "x", hint=STRUCTURE_HINT)
        self.assertEqual(ea.from_engine_error(e).hint, STRUCTURE_HINT)
        self.assertEqual(ea.timeout_report(60).code, "BUILD_TIMEOUT")
        self.assertEqual(ea.cancelled_report().code, "BUILD_CANCELLED")


class RedactTests(unittest.TestCase):
    def test_redaction(self):
        samples = [
            "github_pat_11ABCDEFG0123456789_abcdefghijklmnopqrstuvwxyz",
            "ghp_abcdefghijklmnopqrstuvwxyz0123456789ABCD",
            "Authorization: Bearer abc.def.ghi",
            "https://user:pa55w0rd@example.com/x",
            "https://bucket.r2.example/x?X-Amz-Signature=deadbeef&X-Amz-Credential=AKIA123%2Fx",
            "storePassword = hunter2hunter2", "DATABASE_PASSWORD: s3cr3t!",
        ]
        for s in samples:
            out = logger.redact(s)
            with self.subTest(s=s):
                self.assertIn("[REDACTED]", out)
                for leaked in ("abcdefghijklmnopqrstuvwxyz0123456789ABCD", "abc.def.ghi", "pa55w0rd", "deadbeef", "hunter2", "s3cr3t"):
                    self.assertNotIn(leaked, out)
        self.assertEqual(logger.redact("Task :app:compileDebugKotlin"), "Task :app:compileDebugKotlin")
        self.assertEqual(logger.redact("tok-12345678 here", ["tok-12345678"]), "[REDACTED] here")


if __name__ == "__main__":
    unittest.main()
