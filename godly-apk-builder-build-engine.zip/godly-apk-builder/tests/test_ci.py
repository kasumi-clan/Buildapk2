import io
import os
import subprocess
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

import helpers
import ci_prepare as cp
import ci_summary as cs


def git(repo, *args):
    env = dict(os.environ, GIT_AUTHOR_NAME="t", GIT_AUTHOR_EMAIL="t@t", GIT_COMMITTER_NAME="t", GIT_COMMITTER_EMAIL="t@t")
    return subprocess.run(["git", *args], cwd=repo, env=env, check=True, capture_output=True, text=True).stdout


def commit(repo, message, files):
    for rel, data in files.items():
        p = Path(repo) / rel; p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data if isinstance(data, bytes) else data.encode())
    git(repo, "add", "-A"); git(repo, "commit", "-q", "-m", message)


class PrepareTests(unittest.TestCase):
    def setUp(self):
        self.repo = tempfile.mkdtemp()
        git(self.repo, "init", "-q")
        self.engine = Path(self.repo) / "godly-apk-builder-build-engine.zip"
        self.proj_a = helpers.make_zip(Path(self.repo) / "x.zip", helpers.android_project_files("kts"))
        self.proj_b = helpers.make_zip(Path(self.repo) / "y.zip", helpers.android_project_files("kts"))
        for p in (self.proj_a, self.proj_b):
            os.remove(p)

    def read(self, p):
        return Path(self.repo, p).read_bytes()

    def test_engine_zip_is_never_chosen_as_project(self):
        """Đúng lỗi trong ảnh: push file engine không được coi là dự án Android."""
        commit(self.repo, "add engine", {"godly-apk-builder-build-engine.zip": b"PK engine"})
        self.assertEqual(cp.choose_zip(self.repo, "push"), (None, ["Commit này không thêm/sửa ZIP dự án nào; bỏ qua build."]))
        with self.assertRaises(ValueError) as ctx:
            cp.choose_zip(self.repo, "workflow_dispatch")
        self.assertIn("ZIP của build engine không tính", str(ctx.exception))
        with self.assertRaises(ValueError) as ctx:
            cp.choose_zip(self.repo, "workflow_dispatch", "godly-apk-builder-build-engine.zip")
        self.assertIn("build engine", str(ctx.exception))

    def test_push_picks_zip_changed_in_head_commit(self):
        commit(self.repo, "engine", {"godly-apk-builder-build-engine.zip": b"PK engine"})
        zp = helpers.make_zip(Path(self.repo) / "tmp.zip", helpers.android_project_files("kts"))
        data = Path(zp).read_bytes(); os.remove(zp)
        commit(self.repo, "old project", {"projects/Old.zip": data})
        commit(self.repo, "new project + engine", {"projects/New.zip": data, "godly-apk-builder-build-engine.zip": b"PK engine v2"})
        chosen, notes = cp.choose_zip(self.repo, "push")
        self.assertEqual(chosen, "projects/New.zip")
        self.assertEqual(notes, [])

    def test_dispatch_default_is_newest_project_zip(self):
        data = b"PK\x05\x06" + b"\x00" * 18
        commit(self.repo, "a", {"projects/A.zip": data})
        commit(self.repo, "engine", {"godly-apk-builder-build-engine.zip": b"x"})
        os.environ["GIT_COMMITTER_DATE"] = "2099-01-01T00:00:00"
        try:
            commit(self.repo, "b", {"B.zip": data})
        finally:
            del os.environ["GIT_COMMITTER_DATE"]
        chosen, notes = cp.choose_zip(self.repo, "workflow_dispatch")
        self.assertEqual(chosen, "B.zip")
        self.assertTrue(notes)

    def test_requested_path_validation(self):
        data = b"PK\x05\x06" + b"\x00" * 18
        commit(self.repo, "a", {"projects/A.zip": data, "notes.txt": "x"})
        self.assertEqual(cp.choose_zip(self.repo, "workflow_dispatch", "./projects/A.zip")[0], "projects/A.zip")
        for bad in ("../outside.zip", "/etc/passwd.zip", "notes.txt", "projects/missing.zip", "a\nb.zip"):
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    cp.choose_zip(self.repo, "workflow_dispatch", bad)

    def test_symlink_escape_is_rejected(self):
        outside = Path(tempfile.mkdtemp()) / "secret.zip"; outside.write_bytes(b"x")
        os.symlink(outside, Path(self.repo) / "link.zip")
        with self.assertRaises(ValueError):
            cp.choose_zip(self.repo, "workflow_dispatch", "link.zip")

    def test_no_git_fallback_scans_directory(self):
        plain = tempfile.mkdtemp()
        Path(plain, "P.zip").write_bytes(b"x"); Path(plain, "godly-apk-builder-build-engine.zip").write_bytes(b"y")
        self.assertEqual(cp.choose_zip(plain, "workflow_dispatch")[0], "P.zip")

    def zip_of(self, files):
        p = Path(tempfile.mkdtemp()) / "p.zip"; helpers.make_zip(p, files); return str(p)

    def test_inspect_wrapper_complete_and_version(self):
        info = cp.inspect_wrapper(self.zip_of(helpers.android_project_files("kts")))
        self.assertEqual((info["needs_system_gradle"], info["gradle_version"]), (False, "8.7"))

    def test_inspect_wrapper_missing_jar_or_script_or_all(self):
        files = helpers.android_project_files("kts"); del files["gradle/wrapper/gradle-wrapper.jar"]
        info = cp.inspect_wrapper(self.zip_of(files))
        self.assertTrue(info["needs_system_gradle"]); self.assertEqual(info["gradle_version"], "8.7")
        files = helpers.android_project_files("kts"); del files["gradlew"]
        self.assertTrue(cp.inspect_wrapper(self.zip_of(files))["needs_system_gradle"])
        info = cp.inspect_wrapper(self.zip_of(helpers.android_project_files("kts", wrapper=False)))
        self.assertTrue(info["needs_system_gradle"]); self.assertIsNone(info["gradle_version"])

    def test_inspect_wrapper_with_wrapper_folder_and_bad_zip(self):
        p = Path(tempfile.mkdtemp()) / "w.zip"
        helpers.make_zip(p, helpers.android_project_files("kts"), wrapper_dir="MyProj")
        self.assertFalse(cp.inspect_wrapper(str(p))["needs_system_gradle"])
        bad = Path(tempfile.mkdtemp()) / "bad.zip"; bad.write_bytes(b"nope")
        with self.assertRaises(ValueError):
            cp.inspect_wrapper(str(bad))

    def test_main_writes_outputs_and_rejects_injected_versions(self):
        data = Path(helpers.make_zip(Path(tempfile.mkdtemp()) / "t.zip",
                                     helpers.android_project_files("kts", wrapper=False))).read_bytes()
        commit(self.repo, "p", {"P.zip": data})
        out = Path(tempfile.mkdtemp()) / "out.txt"
        with mock.patch.dict(os.environ, {"GITHUB_OUTPUT": str(out)}):
            self.assertEqual(cp.main(["--repo", self.repo, "--event", "push", "--default-gradle", "8.9"]), 0)
        values = dict(l.split("=", 1) for l in out.read_text().splitlines())
        self.assertEqual(values, {"skip": "false", "zip_path": "P.zip", "needs_system_gradle": "true", "gradle_version": "8.9"})
        out.write_text("")
        with mock.patch.dict(os.environ, {"GITHUB_OUTPUT": str(out)}):
            cp.main(["--repo", self.repo, "--event", "push", "--default-gradle", "8.9; rm -rf /"])
        self.assertIn("gradle_version=8.14.3", out.read_text())  # giá trị lạ bị thay bằng mặc định

    def test_main_skip_and_error_exit_codes(self):
        commit(self.repo, "engine", {"godly-apk-builder-build-engine.zip": b"x"})
        out = Path(tempfile.mkdtemp()) / "o.txt"
        with mock.patch.dict(os.environ, {"GITHUB_OUTPUT": str(out)}):
            self.assertEqual(cp.main(["--repo", self.repo, "--event", "push"]), 0)
            self.assertEqual(out.read_text().strip(), "skip=true")
            self.assertEqual(cp.main(["--repo", self.repo, "--event", "workflow_dispatch"]), 1)


class SummaryTests(unittest.TestCase):
    OK = {"status": "SUCCESS", "error": None, "warnings": ["Đây là APK debug"], "build": {"duration_s": 91.5},
          "apk": {"filename": "Claude.apk", "size": 5 * 1024 * 1024, "sha256": "ab" * 32, "build_type": "debug",
                  "package_name": "com.x.y", "version_name": "1.0", "signature_present": True}}
    FAIL = {"status": "FAILED", "warnings": [], "apk": None,
            "error": {"code": "KOTLIN_COMPILATION_ERROR", "title": "Lỗi biên dịch Kotlin", "cause": "Unresolved reference: foo",
                      "file": "app/src/Main.kt", "line": 12, "hint": "Sửa lỗi ở file/dòng được báo", "retryable": False,
                      "excerpt": ["e: Main.kt:12", "```evil```"]}}

    def test_success_summary(self):
        md = cs.render(self.OK)
        for needle in ("Build APK thành công", "`Claude.apk`", "5.0 MB", "com.x.y", "Chưa kiểm tra", "Artifacts"):
            self.assertIn(needle, md)
        self.assertNotIn("chưa được ký", md)
        self.assertIsNone(cs.annotation(self.OK))

    def test_failure_summary_and_annotation(self):
        md = cs.render(self.FAIL)
        for needle in ("Lỗi biên dịch Kotlin", "app/src/Main.kt", "dòng 12", "Cách khắc phục", "build.log"):
            self.assertIn(needle, md)
        self.assertEqual(md.count("```"), 2)  # fence trong log không phá khối code
        note = cs.annotation(self.FAIL)
        self.assertTrue(note.startswith("::error title=Lỗi biên dịch Kotlin::"))
        self.assertIn("(app/src/Main.kt:12)", note)

    def test_annotation_escapes_newlines(self):
        r = {"status": "FAILED", "error": {"title": "T", "cause": "a\nb%c"}}
        self.assertEqual(cs.annotation(r), "::error title=T::a%0Ab%25c")

    def test_unsigned_and_missing_result_file(self):
        r = dict(self.OK, apk=dict(self.OK["apk"], signature_present=False))
        self.assertIn("chưa được ký", cs.render(r))
        self.assertEqual(cs.main(["--result", "/nonexistent/result.json"]), 0)

    def test_main_writes_step_summary(self):
        tmp = Path(tempfile.mkdtemp()); res = tmp / "r.json"; summ = tmp / "s.md"
        import json; res.write_text(json.dumps(self.OK))
        with mock.patch.dict(os.environ, {"GITHUB_STEP_SUMMARY": str(summ)}):
            cs.main(["--result", str(res)])
        self.assertIn("Build APK thành công", summ.read_text())


if __name__ == "__main__":
    unittest.main()
