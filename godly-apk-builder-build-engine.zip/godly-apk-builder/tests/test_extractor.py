import dataclasses
import os
import stat
import tempfile
import unittest
import warnings
import zipfile
from pathlib import Path
from unittest import mock

import helpers  # noqa: F401  (đặt sys.path)
from config import Config
from errors import EngineError, ErrorCode
import extractor


class ExtractorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.cfg = Config()

    def zip_with(self, entries, name="t.zip"):
        path = self.tmp / name
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
                for info, data in entries:
                    info.compress_type = zipfile.ZIP_DEFLATED
                    z.writestr(info, data)
        return path

    def assert_code(self, code, fn, *a, **kw):
        with self.assertRaises(EngineError) as ctx:
            fn(*a, **kw)
        self.assertEqual(ctx.exception.code, code, ctx.exception.message)
        return ctx.exception

    # --- hợp lệ ---
    def test_valid_zip_with_wrapper_folder_extracts_and_keeps_exec_bit(self):
        path = helpers.make_zip(self.tmp / "ok.zip", {"gradlew": ("#!/bin/sh\n", 0o755), "app/a.txt": "hi"}, wrapper_dir="Proj")
        digest = extractor.verify_zip_file(path, self.cfg)
        rep = extractor.safe_extract(path, self.tmp / "out", self.cfg)
        self.assertEqual(rep.file_count, 2)
        self.assertEqual(len(digest), 64)
        self.assertTrue(os.access(self.tmp / "out/Proj/gradlew", os.X_OK))
        self.assertFalse(os.access(self.tmp / "out/Proj/app/a.txt", os.X_OK))

    def test_macosx_junk_is_skipped(self):
        path = helpers.make_zip(self.tmp / "m.zip", {"__MACOSX/._x": "j", "a/.DS_Store": "j", "a/b.txt": "ok"})
        rep = extractor.safe_extract(path, self.tmp / "out", self.cfg)
        self.assertEqual(rep.file_count, 1)
        self.assertEqual(len(rep.skipped), 2)

    # --- ZIP hỏng / checksum ---
    def test_garbage_file_is_invalid_zip(self):
        p = self.tmp / "g.zip"; p.write_bytes(b"this is not a zip" * 10)
        self.assert_code(ErrorCode.INVALID_ZIP, extractor.verify_zip_file, p, self.cfg)

    def test_truncated_zip_is_invalid(self):
        good = Path(helpers.make_zip(self.tmp / "g.zip", {"a.txt": "x" * 1000}))
        bad = self.tmp / "trunc.zip"; bad.write_bytes(good.read_bytes()[:-30])
        self.assert_code(ErrorCode.INVALID_ZIP, extractor.verify_zip_file, bad, self.cfg)

    def test_empty_and_missing_file(self):
        e = self.tmp / "e.zip"; e.write_bytes(b"")
        self.assert_code(ErrorCode.INVALID_ZIP, extractor.verify_zip_file, e, self.cfg)
        self.assert_code(ErrorCode.INVALID_ZIP, extractor.verify_zip_file, self.tmp / "nope.zip", self.cfg)

    def test_crc_corruption_detected_during_extraction(self):
        p = self.tmp / "c.zip"
        with zipfile.ZipFile(p, "w", zipfile.ZIP_STORED) as z:
            z.writestr("a.bin", b"A" * 5000 + b"MARKER" + b"B" * 5000)
        raw = bytearray(p.read_bytes()); raw[raw.index(b"MARKER")] ^= 0xFF; p.write_bytes(raw)
        self.assert_code(ErrorCode.INVALID_ZIP, extractor.safe_extract, p, self.tmp / "o", self.cfg)

    def test_checksum_mismatch_and_match(self):
        path = helpers.make_zip(self.tmp / "ok.zip", {"a.txt": "hi"})
        real = extractor.sha256_file(path)
        self.assert_code(ErrorCode.STORAGE_ERROR, extractor.verify_zip_file, path, self.cfg, "0" * 64)
        self.assertEqual(extractor.verify_zip_file(path, self.cfg, real.upper()), real)
        self.assert_code(ErrorCode.INTERNAL_ERROR, extractor.verify_zip_file, path, self.cfg, "xyz")

    def test_zip_larger_than_limit(self):
        path = helpers.make_zip(self.tmp / "ok.zip", {"a.txt": "hi" * 100})
        cfg = dataclasses.replace(self.cfg, max_zip_bytes=50)
        self.assert_code(ErrorCode.INVALID_ZIP, extractor.verify_zip_file, path, cfg)

    # --- bảo mật ---
    def test_path_traversal_variants_rejected_and_nothing_written_outside(self):
        for name in ("../evil.txt", "a/../../evil.txt", "..\\evil.txt", "/etc/evil.txt", "C:/evil.txt"):
            with self.subTest(name=name):
                p = self.zip_with([(zipfile.ZipInfo(name), b"x")], "t.zip")
                out = self.tmp / "out"
                self.assert_code(ErrorCode.ZIP_SECURITY_ERROR, extractor.safe_extract, p, out, self.cfg)
                self.assertFalse((self.tmp / "evil.txt").exists())
                self.assertFalse(Path("/etc/evil.txt").exists())

    def _symlink_info(self, name, target):
        info = zipfile.ZipInfo(name); info.create_system = 3
        info.external_attr = (stat.S_IFLNK | 0o777) << 16
        return info, target.encode()

    def test_dangerous_symlinks_rejected(self):
        for target in ("../../etc/passwd", "/etc/passwd"):
            with self.subTest(target=target):
                p = self.zip_with([self._symlink_info("link", target)])
                self.assert_code(ErrorCode.ZIP_SECURITY_ERROR, extractor.safe_extract, p, self.tmp / "o", self.cfg)

    def test_safe_symlink_is_skipped_not_created(self):
        p = self.zip_with([self._symlink_info("a/link", "b.txt"), (zipfile.ZipInfo("a/b.txt"), b"x")])
        rep = extractor.safe_extract(p, self.tmp / "o", self.cfg)
        self.assertFalse(os.path.lexists(self.tmp / "o/a/link"))
        self.assertTrue(any("symlink" in w for w in rep.warnings))

    def test_special_file_type_rejected(self):
        info = zipfile.ZipInfo("dev"); info.create_system = 3; info.external_attr = (stat.S_IFCHR | 0o666) << 16
        p = self.zip_with([(info, b"")])
        self.assert_code(ErrorCode.ZIP_SECURITY_ERROR, extractor.safe_extract, p, self.tmp / "o", self.cfg)

    def test_duplicate_entries_rejected(self):
        p = self.zip_with([(zipfile.ZipInfo("a.txt"), b"1"), (zipfile.ZipInfo("a.txt"), b"2")])
        self.assert_code(ErrorCode.ZIP_SECURITY_ERROR, extractor.safe_extract, p, self.tmp / "o", self.cfg)

    def test_zip_bomb_by_compression_ratio(self):
        p = self.zip_with([(zipfile.ZipInfo("zeros.bin"), b"\x00" * (20 * 1024 * 1024))])
        self.assert_code(ErrorCode.ZIP_SECURITY_ERROR, extractor.safe_extract, p, self.tmp / "o", self.cfg)
        self.assertFalse((self.tmp / "o/zeros.bin").exists())

    def test_zip_bomb_by_total_size(self):
        data = os.urandom(300 * 1024)
        p = self.zip_with([(zipfile.ZipInfo(f"f{i}.bin"), data) for i in range(10)])
        cfg = dataclasses.replace(self.cfg, max_extracted_bytes=1024 * 1024)
        self.assert_code(ErrorCode.ZIP_SECURITY_ERROR, extractor.safe_extract, p, self.tmp / "o", cfg)

    def test_too_many_files(self):
        p = self.zip_with([(zipfile.ZipInfo(f"f{i}.txt"), b"x") for i in range(10)])
        cfg = dataclasses.replace(self.cfg, max_file_count=5)
        self.assert_code(ErrorCode.ZIP_SECURITY_ERROR, extractor.safe_extract, p, self.tmp / "o", cfg)

    def test_extraction_timeout(self):
        p = self.zip_with([(zipfile.ZipInfo(f"f{i}.txt"), b"x") for i in range(3)])
        ticks = iter([0, 10 ** 6, 10 ** 6, 10 ** 6, 10 ** 6])
        with mock.patch("extractor.time.monotonic", side_effect=lambda: next(ticks)):
            e = self.assert_code(ErrorCode.ZIP_SECURITY_ERROR, extractor.safe_extract, p, self.tmp / "o", self.cfg)
        self.assertIn("thời gian", e.message)

    def test_encrypted_flag_rejected(self):
        p = self.zip_with([(zipfile.ZipInfo("a.txt"), b"x")])
        raw = bytearray(p.read_bytes())
        # bật bit 0 (encrypted) trong cả local header và central directory
        for sig, off in ((b"PK\x03\x04", 6), (b"PK\x01\x02", 8)):
            i = raw.index(sig); raw[i + off] |= 1
        p.write_bytes(raw)
        e = self.assert_code(ErrorCode.INVALID_ZIP, extractor.safe_extract, p, self.tmp / "o", self.cfg)
        self.assertIn("mật khẩu", e.message)


if __name__ == "__main__":
    unittest.main()
