"""Test end-to-end của main.run_build. Gradle ở đây là gradlew GIẢ (shell script mô phỏng đầu ra Gradle),
vì sandbox không có Gradle/Android SDK/mạng. Chúng kiểm tra logic điều phối của engine, KHÔNG chứng minh
một dự án Android thật build được."""
import dataclasses
import json
import os
import tempfile
import threading
import unittest
from pathlib import Path
from unittest import mock

import helpers
import extractor
import main
from config import Config


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.out = self.tmp / "out"
        self.ws = self.tmp / "ws"
        self.cfg = dataclasses.replace(Config(), require_toolchain=False, build_timeout_s=60, kill_grace_s=3)

    def run_zip(self, files, name="Claude.zip", wrapper_dir=None, cfg=None, **kw):
        zp = helpers.make_zip(self.tmp / name, files, wrapper_dir=wrapper_dir)
        params = main.BuildParams(zip_path=zp, output_dir=str(self.out), workspace_base=str(self.ws), **kw)
        return zp, main.run_build(params, cfg or self.cfg)

    def stages(self):
        return [h["status"] for h in json.loads((self.out / "status.json").read_text())["history"]]

    def test_success_named_after_zip_and_workspace_cleaned(self):
        zp, r = self.run_zip(helpers.android_project_files("kts"), wrapper_dir="MyAndroidProject")
        before = extractor.sha256_file(zp)
        self.assertEqual(r["status"], "SUCCESS", r["error"])
        self.assertEqual(r["apk"]["filename"], "Claude.apk")
        apk = self.out / "Claude.apk"
        self.assertEqual(r["apk"]["sha256"], extractor.sha256_file(apk))
        self.assertEqual(r["apk"]["size"], apk.stat().st_size)
        self.assertEqual(r["apk"]["build_type"], "debug")
        self.assertEqual(r["apk"]["package_name"], "com.example.app")
        self.assertEqual(r["verification"], {"BUILD_SUCCESS": True, "APK_VALIDATED": True,
                                             "INSTALL_TESTED": False, "APP_RUNTIME_TESTED": False})
        self.assertTrue(any("debug" in w.lower() for w in r["warnings"]))
        self.assertEqual(self.stages(), ["VALIDATING", "EXTRACTING", "VALIDATING", "CONFIGURING", "BUILDING", "PACKAGING", "SUCCESS"])
        self.assertEqual(os.listdir(self.ws), [])
        self.assertEqual(extractor.sha256_file(zp), before)  # ZIP nguồn không bị ghi đè
        self.assertTrue(json.loads((self.out / "result.json").read_text())["status"] == "SUCCESS")

    def test_second_build_never_overwrites_previous_apk(self):
        self.run_zip(helpers.android_project_files("kts"))
        first = (self.out / "Claude.apk").read_bytes()
        _, r = self.run_zip(helpers.android_project_files("kts"))
        self.assertEqual(r["apk"]["filename"], "Claude-1.apk")
        self.assertEqual((self.out / "Claude.apk").read_bytes(), first)

    def test_checksum_verified_flag_and_mismatch(self):
        zp = helpers.make_zip(self.tmp / "Claude.zip", helpers.android_project_files("kts"))
        good = extractor.sha256_file(zp)
        r = main.run_build(main.BuildParams(zp, str(self.out), str(self.ws), expected_sha256=good), self.cfg)
        self.assertEqual(r["status"], "SUCCESS"); self.assertTrue(r["zip"]["checksum_verified"])
        r = main.run_build(main.BuildParams(zp, str(self.tmp / "o2"), str(self.ws), expected_sha256="1" * 64), self.cfg)
        self.assertEqual((r["status"], r["error"]["code"]), ("FAILED", "STORAGE_ERROR"))
        self.assertIsNone(r["apk"])

    def test_invalid_and_unsafe_zip_and_missing_project(self):
        bad = self.tmp / "bad.zip"; bad.write_bytes(b"nope" * 50)
        r = main.run_build(main.BuildParams(str(bad), str(self.out), str(self.ws)), self.cfg)
        self.assertEqual(r["error"]["code"], "INVALID_ZIP")
        _, r = self.run_zip({"../evil.sh": "x"}, name="evil.zip")
        self.assertEqual(r["error"]["code"], "ZIP_SECURITY_ERROR")
        _, r = self.run_zip({"README.md": "no project here"}, name="empty.zip")
        self.assertEqual((r["status"], r["error"]["code"]), ("FAILED", "PROJECT_NOT_FOUND"))
        self.assertIn("settings.gradle", r["error"]["hint"])
        _, r = self.run_zip(helpers.android_project_files("kts", wrapper=False), name="nowrap.zip")
        self.assertEqual(r["error"]["code"], "GRADLE_WRAPPER_MISSING")

    def test_kotlin_compile_error_reports_real_location_and_no_apk(self):
        _, r = self.run_zip(helpers.android_project_files("kts", mode="kotlin_error"))
        self.assertEqual(r["status"], "FAILED")
        e = r["error"]
        self.assertEqual((e["code"], e["file"], e["line"]), ("KOTLIN_COMPILATION_ERROR", "app/src/main/java/com/x/MainActivity.kt", 12))
        self.assertIsNone(r["apk"]); self.assertFalse(r["verification"]["BUILD_SUCCESS"])
        self.assertEqual(r["build"]["exit_code"], 1)
        self.assertEqual(self.stages()[-1], "FAILED")
        self.assertFalse(list(self.out.glob("*.apk")))

    def test_network_error_is_retryable(self):
        _, r = self.run_zip(helpers.android_project_files("kts", mode="network"))
        self.assertEqual(r["error"]["code"], "NETWORK_ERROR"); self.assertTrue(r["error"]["retryable"])

    def test_unknown_failure_is_not_fabricated(self):
        _, r = self.run_zip(helpers.android_project_files("kts", mode="unknown"))
        self.assertEqual(r["error"]["code"], "UNKNOWN_BUILD_ERROR")
        self.assertIn("Không thể xác định chính xác nguyên nhân", r["error"]["cause"])
        self.assertIsNone(r["error"]["file"])

    def test_exit0_without_apk_is_not_success(self):
        _, r = self.run_zip(helpers.android_project_files("kts", mode="no_apk"))
        self.assertEqual((r["status"], r["error"]["code"]), ("FAILED", "APK_NOT_FOUND"))
        self.assertTrue(r["verification"]["BUILD_SUCCESS"]); self.assertFalse(r["verification"]["APK_VALIDATED"])

    def test_stale_apk_shipped_inside_zip_is_never_returned(self):
        files = helpers.android_project_files("kts", mode="no_apk")
        files["app/build/outputs/apk/debug/app-debug.apk"] = helpers.make_apk_bytes()
        _, r = self.run_zip(files)
        self.assertEqual((r["status"], r["error"]["code"]), ("FAILED", "APK_NOT_FOUND"))
        self.assertFalse(list(self.out.glob("*.apk")))

    def test_invalid_apk_output_rejected(self):
        _, r = self.run_zip(helpers.android_project_files("kts", apk=b"not an apk"))
        self.assertEqual((r["status"], r["error"]["code"]), ("FAILED", "APK_VALIDATION_ERROR"))
        self.assertFalse(r["verification"]["APK_VALIDATED"])

    def test_multiple_apks_flagged_not_hidden(self):
        _, r = self.run_zip(helpers.android_project_files("kts", mode="multi"))
        self.assertEqual(r["status"], "SUCCESS")
        self.assertTrue(r["ambiguous_variants"])
        self.assertIn("universal", r["apk"]["source"])
        self.assertEqual(len(r["other_apks"]), 1)

    def test_release_without_apk_for_variant(self):
        _, r = self.run_zip(helpers.android_project_files("kts"), variant="release")
        self.assertEqual((r["status"], r["error"]["code"]), ("FAILED", "APK_NOT_FOUND"))

    def test_timeout(self):
        cfg = dataclasses.replace(self.cfg, build_timeout_s=1)
        _, r = self.run_zip(helpers.android_project_files("kts", mode="sleep"), cfg=cfg)
        self.assertEqual((r["status"], r["error"]["code"]), ("TIMEOUT", "BUILD_TIMEOUT"))
        self.assertEqual(os.listdir(self.ws), [])

    def test_cancel_during_build_confirms_stop(self):
        ev = threading.Event()
        threading.Timer(1.5, ev.set).start()
        zp = helpers.make_zip(self.tmp / "Claude.zip", helpers.android_project_files("kts", mode="sleep"))
        r = main.run_build(main.BuildParams(zp, str(self.out), str(self.ws)), self.cfg, cancel_event=ev)
        self.assertEqual((r["status"], r["error"]["code"]), ("CANCELLED", "BUILD_CANCELLED"))
        self.assertIn("CANCEL_REQUESTED", self.stages()); self.assertEqual(self.stages()[-1], "CANCELLED")
        self.assertEqual(os.listdir(self.ws), [])

    def test_cancel_before_start(self):
        ev = threading.Event(); ev.set()
        zp = helpers.make_zip(self.tmp / "Claude.zip", helpers.android_project_files("kts"))
        r = main.run_build(main.BuildParams(zp, str(self.out), str(self.ws)), self.cfg, cancel_event=ev)
        self.assertEqual(r["status"], "CANCELLED")

    def test_toolchain_preflight(self):
        cfg = dataclasses.replace(self.cfg, require_toolchain=True)
        env = helpers.fake_toolchain_env(self.tmp)
        files = helpers.android_project_files("kts")
        with mock.patch.dict(os.environ, {"JAVA_HOME": "/nonexistent-jdk", "ANDROID_HOME": env["ANDROID_HOME"]}):
            _, r = self.run_zip(files, cfg=cfg)
        self.assertEqual(r["error"]["code"], "JDK_ERROR")
        with mock.patch.dict(os.environ, {"JAVA_HOME": env["JAVA_HOME"]}):
            os.environ.pop("ANDROID_HOME", None); os.environ.pop("ANDROID_SDK_ROOT", None)
            _, r = self.run_zip(files, cfg=cfg)
        self.assertEqual(r["error"]["code"], "ANDROID_SDK_ERROR")
        with mock.patch.dict(os.environ, env):
            _, r = self.run_zip(files, cfg=cfg)
        self.assertEqual(r["status"], "SUCCESS")

    def test_secrets_never_reach_log_or_result(self):
        token = "ghp_abcdefghijklmnopqrstuvwxyz0123456789ABCD"
        _, r = self.run_zip(helpers.android_project_files("kts", mode="secret"))
        for name in ("build.log", "result.json", "status.json"):
            self.assertNotIn(token, (self.out / name).read_text(), name)
        self.assertIn("[REDACTED]", (self.out / "build.log").read_text())

    def test_user_supplied_local_properties_and_flavor_injection(self):
        files = helpers.android_project_files("kts")
        files["local.properties"] = "sdk.dir=/Users/someone/Library/Android/sdk\n"
        _, r = self.run_zip(files)
        self.assertEqual(r["status"], "SUCCESS")
        _, r = self.run_zip(helpers.android_project_files("kts"), flavor="x; rm -rf /")
        self.assertEqual(r["status"], "FAILED"); self.assertEqual(r["error"]["code"], "GRADLE_CONFIGURATION_ERROR")

    def _fake_gradle_on_path(self):
        bin_dir = self.tmp / "bin"; bin_dir.mkdir(exist_ok=True)
        gradle = bin_dir / "gradle"; gradle.write_text(helpers.FAKE_GRADLEW); gradle.chmod(0o755)
        return {"PATH": f"{bin_dir}:{os.environ['PATH']}"}

    def test_system_gradle_fallback_when_wrapper_missing(self):
        files = helpers.android_project_files("kts", wrapper=False)
        with mock.patch.dict(os.environ, self._fake_gradle_on_path()):
            _, r = self.run_zip(files, system_gradle=True)
        self.assertEqual(r["status"], "SUCCESS", r["error"])
        self.assertEqual(r["build"]["gradle"], "system")
        self.assertTrue(any("Gradle cài sẵn" in w for w in r["warnings"]))

    def test_wrapper_is_preferred_even_when_system_gradle_allowed(self):
        with mock.patch.dict(os.environ, self._fake_gradle_on_path()):
            _, r = self.run_zip(helpers.android_project_files("kts"), system_gradle=True)
        self.assertEqual((r["status"], r["build"]["gradle"]), ("SUCCESS", "wrapper"))

    def test_missing_wrapper_still_fails_without_flag_or_without_gradle(self):
        files = helpers.android_project_files("kts", wrapper=False)
        with mock.patch.dict(os.environ, self._fake_gradle_on_path()):
            _, r = self.run_zip(files)
        self.assertEqual(r["error"]["code"], "GRADLE_WRAPPER_MISSING")
        with mock.patch("gradle_runner.shutil.which", return_value=None):
            _, r = self.run_zip(files, system_gradle=True)
        self.assertEqual((r["status"], r["error"]["code"]), ("FAILED", "GRADLE_WRAPPER_MISSING"))

    def test_cli_exit_codes(self):
        zp = helpers.make_zip(self.tmp / "Claude.zip", helpers.android_project_files("kts"))
        argv = ["--zip", zp, "--output-dir", str(self.out), "--workspace", str(self.ws)]
        with mock.patch.dict(os.environ, {"GODLY_REQUIRE_TOOLCHAIN": "false"}):
            self.assertEqual(main.main(argv), 0)
            bad = helpers.make_zip(self.tmp / "b.zip", helpers.android_project_files("kts", mode="kotlin_error"))
            self.assertEqual(main.main(["--zip", bad, "--output-dir", str(self.tmp / "o2"), "--workspace", str(self.ws)]), 1)


if __name__ == "__main__":
    unittest.main()
