import os
import unittest
from unittest import mock

import helpers  # noqa: F401
from config import Config, MB


class ConfigTests(unittest.TestCase):
    def test_defaults_match_spec(self):
        c = Config()
        self.assertEqual(c.max_zip_bytes, 200 * MB)
        self.assertTrue(c.require_toolchain)

    def test_env_overrides_and_validation(self):
        with mock.patch.dict(os.environ, {"GODLY_MAX_ZIP_MB": "50", "GODLY_BUILD_TIMEOUT_S": "900",
                                          "GODLY_ALLOWED_GRADLE_HOSTS": "a.example, B.example"}):
            c = Config.from_env()
        self.assertEqual((c.max_zip_bytes, c.build_timeout_s), (50 * MB, 900))
        self.assertEqual(c.allowed_gradle_hosts, ("a.example", "b.example"))
        for bad in ("abc", "0", "-5"):
            with mock.patch.dict(os.environ, {"GODLY_MAX_FILES": bad}):
                with self.assertRaises(ValueError):
                    Config.from_env()


if __name__ == "__main__":
    unittest.main()
