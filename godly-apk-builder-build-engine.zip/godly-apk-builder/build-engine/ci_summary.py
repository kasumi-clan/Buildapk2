"""Tóm tắt result.json thành Markdown cho trang Summary của GitHub Actions (đọc được trên điện thoại)."""
from __future__ import annotations

import argparse
import json
import os
import sys

_ICON = {"SUCCESS": "✅", "FAILED": "❌", "CANCELLED": "⛔", "TIMEOUT": "⏱️"}


def _size(n) -> str:
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return ""


def _fence(lines) -> str:
    body = "\n".join(str(l) for l in lines).replace("```", "'''")
    return f"```\n{body}\n```"


def render(result: dict) -> str:
    status = result.get("status", "FAILED")
    icon = _ICON.get(status, "❔")
    out: list = []
    err = result.get("error")
    apk = result.get("apk")
    if status == "SUCCESS" and apk:
        out.append(f"## {icon} Build APK thành công")
        out += ["", "| Mục | Giá trị |", "|---|---|",
                f"| APK | `{apk['filename']}` |", f"| Dung lượng | {_size(apk['size'])} |",
                f"| Loại build | {apk['build_type']} |", f"| SHA-256 | `{apk['sha256']}` |"]
        if apk.get("package_name"):
            ver = f" ({apk['version_name']})" if apk.get("version_name") else ""
            out.append(f"| Package | `{apk['package_name']}`{ver} |")
        out.append(f"| Thời gian Gradle | {result.get('build', {}).get('duration_s', '?')} giây |")
        out += ["", "Tải APK: kéo xuống mục **Artifacts** ở cuối trang này, bấm `apk-…` (tải về là file ZIP chứa APK).",
                "", "**Đã kiểm tra:** Gradle build xong, cấu trúc file APK hợp lệ.",
                "**Chưa kiểm tra:** cài đặt và chạy thật trên điện thoại."]
        if not apk.get("signature_present"):
            out.append("\n> ⚠️ APK chưa được ký nên không cài được trên điện thoại.")
    else:
        title = (err or {}).get("title", "Build không thành công")
        out.append(f"## {icon} {title}")
        if err:
            out += ["", f"**Mã lỗi:** `{err.get('code')}`", f"**Nguyên nhân:** {err.get('cause')}"]
            if err.get("file"):
                out.append(f"**Vị trí:** `{err['file']}`" + (f" dòng {err['line']}" if err.get("line") else ""))
            if err.get("hint"):
                out.append(f"**Cách khắc phục:** {err['hint']}")
            if err.get("excerpt"):
                out += ["", "**Trích log:**", _fence(err["excerpt"])]
            out.append("\nCó thể thử build lại." if err.get("retryable") else "\nCần sửa dự án rồi nén và upload lại.")
        out.append("\nLog đầy đủ nằm trong artifact `apk-…` (file `build.log`).")
    if result.get("warnings"):
        out += ["", "**Cảnh báo:**"] + [f"- {w}" for w in result["warnings"]]
    return "\n".join(out) + "\n"


def _escape(msg: str) -> str:
    return msg.replace("%", "%25").replace("\r", "%0D").replace("\n", "%0A")


def annotation(result: dict) -> str | None:
    err = result.get("error")
    if result.get("status") == "SUCCESS" or not err:
        return None
    where = f" ({err['file']}:{err['line']})" if err.get("file") and err.get("line") else ""
    return f"::error title={_escape(str(err.get('title')))}::{_escape(str(err.get('cause')) + where)}"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--result", required=True)
    ns = ap.parse_args(argv)
    try:
        with open(ns.result, encoding="utf-8") as fh:
            result = json.load(fh)
    except (OSError, ValueError):
        print("::error title=Không có kết quả::Build engine không tạo được result.json; xem log của bước Build APK.")
        return 0
    text = render(result)
    target = os.environ.get("GITHUB_STEP_SUMMARY")
    if target:
        with open(target, "a", encoding="utf-8") as fh:
            fh.write(text)
    else:
        print(text)
    note = annotation(result)
    if note:
        print(note)
    return 0


if __name__ == "__main__":
    sys.exit(main())
