"""Điều phối build: ZIP -> kiểm tra -> giải nén -> phát hiện dự án -> Gradle -> APK -> kết quả.

Chạy:  python main.py --zip Claude.zip --output-dir out --workspace /tmp/work --sha256 <hex>
Ghi ra output-dir: build.log, status.json (giai đoạn thật), result.json, <tên-zip>.apk (nếu thành công).
Exit code: 0 SUCCESS, 1 FAILED, 2 CANCELLED, 3 TIMEOUT.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import signal
import tempfile
import threading
import time
import traceback
from dataclasses import dataclass
from pathlib import Path

import apk_validator
import cleanup
import error_analyzer
import extractor
import gradle_runner
import project_detector
import validator
from config import Config
from errors import BuildCancelled, EngineError, ErrorCode
from logger import BuildLogger, Status, StatusReporter, now_iso, write_json_atomic

EXIT_CODES = {"SUCCESS": 0, "FAILED": 1, "CANCELLED": 2, "TIMEOUT": 3}


@dataclass
class BuildParams:
    zip_path: str
    output_dir: str
    workspace_base: str
    variant: str = "debug"            # debug | release
    module: str | None = None
    flavor: str | None = None
    expected_sha256: str | None = None
    output_name: str | None = None
    keep_workspace: bool = False
    cancel_file: str | None = None
    system_gradle: bool = False       # cho phép dùng lệnh `gradle` có sẵn khi dự án thiếu wrapper


def safe_output_name(zip_path: str, override: str | None = None) -> str:
    base = override or Path(zip_path).name
    base = re.sub(r"(?i)\.zip$", "", base)
    base = re.sub(r"[\x00-\x1f/\\:*?\"<>|]", "_", base).strip(" .")[:100]
    return base or "app"


def _unique_path(directory: Path, stem: str, suffix: str) -> Path:
    candidate = directory / f"{stem}{suffix}"
    n = 1
    while candidate.exists():
        candidate = directory / f"{stem}-{n}{suffix}"
        n += 1
    return candidate


def run_build(params: BuildParams, cfg: Config | None = None, cancel_event: threading.Event | None = None) -> dict:
    cfg = cfg or Config.from_env()
    out = Path(params.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    logger = BuildLogger(out / "build.log", max_bytes=cfg.max_log_bytes)
    status = StatusReporter(out / "status.json")
    started_ts = time.time()
    result: dict = {
        "status": None, "error": None, "started_at": now_iso(), "finished_at": None,
        "verification": {"BUILD_SUCCESS": False, "APK_VALIDATED": False,
                         "INSTALL_TESTED": False, "APP_RUNTIME_TESTED": False},
        "note": "APK_VALIDATED chỉ là kiểm tra cấu trúc file APK. INSTALL_TESTED/APP_RUNTIME_TESTED luôn false "
                "vì engine không chạy emulator/thiết bị thật.",
        "zip": {"name": Path(params.zip_path).name}, "build": {"variant": params.variant},
        "apk": None, "other_apks": [], "ambiguous_variants": False, "warnings": [],
    }
    workspace: Path | None = None
    terminal = Status.FAILED

    def cancelled() -> bool:
        return bool((cancel_event and cancel_event.is_set()) or (params.cancel_file and Path(params.cancel_file).exists()))

    def stage(s: Status, msg: str) -> None:
        if cancelled():
            raise BuildCancelled()
        logger.set_stage(s)
        logger.info(msg)
        status.update(s, msg)

    try:
        if params.variant not in ("debug", "release"):
            raise EngineError(ErrorCode.GRADLE_CONFIGURATION_ERROR, "variant phải là debug hoặc release.")
        base = Path(params.workspace_base)
        base.mkdir(parents=True, exist_ok=True)
        workspace = Path(tempfile.mkdtemp(prefix="godly-build-", dir=base))

        stage(Status.VALIDATING, "Kiểm tra file ZIP (dung lượng, checksum, định dạng)")
        digest = extractor.verify_zip_file(params.zip_path, cfg, params.expected_sha256)
        result["zip"].update(size=Path(params.zip_path).stat().st_size, sha256=digest,
                             checksum_verified=bool(params.expected_sha256))

        stage(Status.EXTRACTING, "Giải nén ZIP an toàn")
        extract_dir = workspace / "src"
        report = extractor.safe_extract(params.zip_path, extract_dir, cfg)
        result["warnings"] += report.warnings
        logger.info(f"Đã giải nén {report.file_count} file, {report.total_bytes} byte")

        stage(Status.VALIDATING, "Tìm và kiểm tra dự án Android")
        info = project_detector.detect_project(extract_dir, cfg.max_project_depth)
        result["warnings"] += validator.validate_project(info, cfg, params.system_gradle)
        use_system = params.system_gradle and validator.wrapper_problem(info) is not None
        module = validator.resolve_app_module(info, params.module)
        result["project"] = {
            "root": str(info.root.relative_to(extract_dir)) or ".", "dsl": info.dsl,
            "modules": [m.gradle_path for m in info.modules],
            "application_modules": [m.gradle_path for m in info.application_modules],
            "flavors": {m.gradle_path: m.flavors for m in info.application_modules if m.flavors},
        }

        stage(Status.CONFIGURING, "Chuẩn bị workspace và kiểm tra JDK/Android SDK")
        cleanup.remove_stale_outputs(info.root, logger)
        if cfg.require_toolchain:
            gradle_runner.check_toolchain()
        task = gradle_runner.build_task_name(module.gradle_path if module else None, params.variant, params.flavor)

        stage(Status.BUILDING, f"Gradle: {task}")
        build_started = time.time()
        gres = gradle_runner.run_gradle(info.root, task, cfg, logger, cancel_event=cancel_event,
                                        cancel_file=params.cancel_file, use_system_gradle=use_system)
        result["build"].update(task=task, exit_code=gres.exit_code, duration_s=gres.duration_s,
                               gradle="system" if use_system else "wrapper")
        if gres.cancelled:
            status.update(Status.CANCEL_REQUESTED, "Đã nhận yêu cầu huỷ, đang xác nhận Gradle dừng")
            if not gres.stopped_confirmed:
                raise EngineError(ErrorCode.INTERNAL_ERROR, "Đã yêu cầu huỷ nhưng chưa xác nhận được tiến trình Gradle đã dừng.")
            raise BuildCancelled()
        if gres.timed_out:
            terminal = Status.TIMEOUT
            result["error"] = error_analyzer.timeout_report(cfg.build_timeout_s).to_dict()
            raise _Finished()
        if gres.exit_code != 0:
            result["error"] = error_analyzer.analyze_gradle_log(
                logger.tail(), strip_prefixes=(info.root, extract_dir, workspace)).to_dict()
            raise _Finished()
        result["verification"]["BUILD_SUCCESS"] = True

        stage(Status.PACKAGING, "Tìm và kiểm tra APK")
        candidates = apk_validator.find_apk_candidates(info.root, since_ts=build_started - 2)
        if not candidates:
            raise EngineError(ErrorCode.APK_NOT_FOUND, "Gradle chạy xong (exit 0) nhưng không tìm thấy APK mới trong build/outputs/apk.",
                              hint="Kiểm tra module/flavor/build type; dự án có thể chỉ build AAB hoặc thư viện.")
        selection = apk_validator.select_apk(candidates, params.variant)
        if selection.chosen is None:
            raise EngineError(ErrorCode.APK_NOT_FOUND, f"Có APK nhưng không có APK nào thuộc build type '{params.variant}'.")
        apk = apk_validator.validate_apk(selection.chosen)
        result["verification"]["APK_VALIDATED"] = True
        name = safe_output_name(params.zip_path, params.output_name)
        dest = _unique_path(out, name, ".apk")
        shutil.copyfile(apk.path, dest)
        if extractor.sha256_file(dest) != apk.sha256:
            dest.unlink(missing_ok=True)
            raise EngineError(ErrorCode.STORAGE_ERROR, "SHA-256 của APK sau khi lưu không khớp bản gốc.")
        result["apk"] = {
            "filename": dest.name, "size": apk.size, "sha256": apk.sha256, "build_type": params.variant,
            "package_name": apk.package_name, "version_name": apk.version_name, "version_code": apk.version_code,
            "debuggable": apk.debuggable, "signature_present": apk.signature_present,
            "source": str(apk.path.relative_to(info.root)),
        }
        result["other_apks"] = [str(p.relative_to(info.root)) for p in selection.others]
        result["ambiguous_variants"] = selection.ambiguous
        result["warnings"] += apk.warnings
        if selection.ambiguous:
            result["warnings"].append("Gradle tạo nhiều APK cùng build type; đã chọn 1 APK, các APK còn lại nằm trong other_apks.")
        if params.variant == "debug":
            result["warnings"].append("Đây là APK debug (ký bằng debug key), không phải bản release.")
        terminal = Status.SUCCESS
    except _Finished:
        pass
    except BuildCancelled:
        terminal = Status.CANCELLED
        result["error"] = error_analyzer.cancelled_report().to_dict()
    except EngineError as exc:
        logger.error(f"{exc.code.value}: {exc.message}")
        result["error"] = error_analyzer.from_engine_error(exc).to_dict()
    except Exception as exc:  # lỗi ngoài dự kiến của engine
        logger.error("Lỗi nội bộ: " + "".join(traceback.format_exception_only(type(exc), exc)).strip())
        logger.log(traceback.format_exc(), "DEBUG")
        result["error"] = error_analyzer.from_engine_error(
            EngineError(ErrorCode.INTERNAL_ERROR, "Build engine gặp lỗi không mong đợi.")).to_dict()
    finally:
        try:
            if workspace and not params.keep_workspace:
                cleanup.safe_rmtree(workspace, workspace.parent)
        except Exception as exc:
            logger.warn(f"Không dọn được workspace: {exc}")
        result["status"] = terminal.value
        result["finished_at"] = now_iso()
        result["build"]["total_duration_s"] = round(time.time() - started_ts, 2)
        logger.set_stage(terminal)
        logger.info(f"Kết thúc: {terminal.value}")
        status.update(terminal, "Hoàn tất" if terminal == Status.SUCCESS else (result["error"] or {}).get("title", ""))
        write_json_atomic(out / "result.json", result)
        logger.close()
    return result


class _Finished(Exception):
    """Dừng pipeline sau khi đã ghi kết quả lỗi build."""


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="godly-build-engine")
    ap.add_argument("--zip", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--workspace", required=True, help="thư mục chứa các job tạm (sẽ tạo thư mục con riêng)")
    ap.add_argument("--sha256")
    ap.add_argument("--variant", choices=("debug", "release"), default="debug")
    ap.add_argument("--module")
    ap.add_argument("--flavor")
    ap.add_argument("--output-name")
    ap.add_argument("--cancel-file")
    ap.add_argument("--keep-workspace", action="store_true")
    ap.add_argument("--system-gradle", action="store_true",
                    help="nếu dự án thiếu gradle wrapper thì dùng lệnh `gradle` có sẵn (wrapper đầy đủ vẫn được ưu tiên)")
    ns = ap.parse_args(argv)
    cancel = threading.Event()
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, lambda *_: cancel.set())
    result = run_build(BuildParams(
        zip_path=ns.zip, output_dir=ns.output_dir, workspace_base=ns.workspace, variant=ns.variant,
        module=ns.module, flavor=ns.flavor, expected_sha256=ns.sha256, output_name=ns.output_name,
        keep_workspace=ns.keep_workspace, cancel_file=ns.cancel_file,
        system_gradle=ns.system_gradle), cancel_event=cancel)
    print(json.dumps({"status": result["status"], "error_code": (result["error"] or {}).get("code"),
                      "apk": (result["apk"] or {}).get("filename"), "sha256": (result["apk"] or {}).get("sha256")},
                     ensure_ascii=False))
    return EXIT_CODES[result["status"]]


if __name__ == "__main__":
    raise SystemExit(main())
