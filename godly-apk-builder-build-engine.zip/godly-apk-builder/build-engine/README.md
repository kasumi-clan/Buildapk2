# Godly APK Builder — Python build engine

Phần "ruột" của quy trình build: nhận file ZIP dự án Android, kiểm tra, giải nén an toàn, tìm dự án,
chạy `./gradlew`, kiểm tra APK và ghi kết quả. Chỉ dùng thư viện chuẩn Python (>= 3.9). Chạy trên Linux/macOS.

## Chạy
```
python main.py --zip Claude.zip --output-dir out --workspace /tmp/godly-work \
               --sha256 <sha256-của-zip> [--variant debug|release] [--module :app] [--flavor free]
```
Cần sẵn JDK và Android SDK (`JAVA_HOME`, `ANDROID_HOME`) — trên GitHub Actions dùng `actions/setup-java` và
`android-actions/setup-android`. Thiếu thì engine dừng sớm với `JDK_ERROR` / `ANDROID_SDK_ERROR`.

Kết quả trong `--output-dir`: `Claude.apk` (tên theo ZIP, không ghi đè bản cũ), `build.log` (đã che secret),
`status.json` (giai đoạn thật, không có % giả), `result.json`.
Exit code: 0 SUCCESS · 1 FAILED · 2 CANCELLED · 3 TIMEOUT. Huỷ: gửi SIGTERM/SIGINT hoặc tạo file `--cancel-file`.

## Dùng trên GitHub Actions (file `.github/workflows/android-build.yml`)
Repo cần có: `godly-apk-builder-build-engine.zip` ở thư mục gốc (engine, KHÔNG phải dự án) và workflow trên.
Upload ZIP dự án Android vào repo (ví dụ `projects/`) -> workflow tự chạy; hoặc Actions -> Run workflow.
`ci_prepare.py` chọn ZIP dự án (bỏ qua ZIP engine), `main.py` build, `ci_summary.py` ghi kết quả ra trang Summary;
APK nằm trong artifact `apk-<số lần chạy>`. Nếu ZIP thiếu `gradle-wrapper.jar`, workflow cài Gradle theo
`gradle-wrapper.properties` (hoặc 8.14.3) và engine chạy với `--system-gradle` (wrapper đầy đủ vẫn được ưu tiên).
Không dùng cache Gradle để tránh nhiễm cache chéo giữa các lần build.

## Test
```
python -m unittest discover -s ../tests -v
```
Test dùng **gradlew giả** (script shell in ra đầu ra giống Gradle) để kiểm tra logic điều phối. Chúng không chứng minh
một dự án Android thật build được; việc đó cần chạy thử trên runner có Gradle + Android SDK + mạng.

## Đảm bảo bảo mật
- ZIP: chặn path traversal (kể cả `..\`, đường dẫn tuyệt đối, ổ đĩa), symlink nguy hiểm, file đặc biệt, entry trùng,
  ZIP bomb (tổng dung lượng, tỉ lệ nén, số file, thời gian), ZIP có mật khẩu.
- Gradle chỉ nhận biến môi trường trong danh sách cho phép (`config.DEFAULT_ENV_PASSTHROUGH`): token, DB, storage
  credentials không tới được mã Gradle của người dùng.
- `distributionUrl` của wrapper chỉ được trỏ tới host cho phép. `variant/module/flavor` được kiểm tra trước khi thành tham số Gradle.
- Build.gradle của người dùng vẫn là code tuỳ ý: phải chạy trên runner dùng một lần, không đặc quyền, không có secret.

## Chưa có trong phần này
Frontend, backend/API, đăng nhập, database, upload R2/S3, kết nối GitHub PAT, callback về backend,
quota, tải APK qua signed URL, và các tài liệu còn lại. Engine cũng không ký release APK và không chạy emulator
(`INSTALL_TESTED`/`APP_RUNTIME_TESTED` luôn `false`).
