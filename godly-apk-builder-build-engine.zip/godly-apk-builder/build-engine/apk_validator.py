"""Tìm, chọn và kiểm tra cấu trúc APK. Chỉ xác nhận cấu trúc hợp lệ, KHÔNG xác nhận cài đặt/chạy được."""
from __future__ import annotations

import json
import os
import struct
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

from errors import EngineError, ErrorCode
from extractor import sha256_file

_MAX_MANIFEST = 10 * 1024 * 1024


@dataclass
class ApkReport:
    path: Path
    size: int
    sha256: str
    package_name: str | None = None
    version_name: str | None = None
    version_code: int | None = None
    debuggable: bool | None = None
    signature_present: bool = False
    has_classes_dex: bool = False
    warnings: list = field(default_factory=list)


@dataclass
class ApkSelection:
    chosen: Path | None
    others: list
    ambiguous: bool


def find_apk_candidates(project_root: Path | str, since_ts: float | None = None) -> list:
    """APK nằm trong build/outputs/apk/**, bỏ androidTest, bỏ symlink, và (nếu có since_ts) chỉ lấy file mới."""
    root = Path(project_root)
    root_real = os.path.realpath(root)
    found: list = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in (".git", "node_modules", ".gradle")]
        for name in filenames:
            if not name.lower().endswith(".apk"):
                continue
            p = Path(dirpath) / name
            parts = p.relative_to(root).parts
            if "outputs" not in parts or "apk" not in parts or "androidTest" in parts or p.is_symlink():
                continue
            if not os.path.realpath(p).startswith(root_real + os.sep):
                continue
            if since_ts is not None and p.stat().st_mtime < since_ts:
                continue
            found.append(p)
    return sorted(found)


def select_apk(candidates: list, build_type: str) -> ApkSelection:
    matching = [p for p in candidates if p.parent.name.lower() == build_type.lower()]
    if not matching:
        return ApkSelection(None, list(candidates), False)
    if len(matching) == 1:
        return ApkSelection(matching[0], [p for p in candidates if p != matching[0]], False)
    universal = [p for p in matching if "universal" in p.name.lower()]
    chosen = universal[0] if len(universal) == 1 else matching[0]
    return ApkSelection(chosen, [p for p in candidates if p != chosen], True)


# ---- đọc AndroidManifest.xml dạng nhị phân (AXML) -----------------------------------------

def _read_string_pool(data: bytes, pos: int) -> list:
    _, header_size, _size, count, _styles, flags, strings_start, _ss = struct.unpack_from("<HHIIIIII", data, pos)
    offsets = struct.unpack_from(f"<{count}I", data, pos + header_size)
    utf8 = bool(flags & 0x100)
    strings: list = []
    for off in offsets:
        p = pos + strings_start + off
        if utf8:
            n = data[p]; p += 1
            if n & 0x80:
                n = ((n & 0x7F) << 8) | data[p]; p += 1
            b = data[p]; p += 1
            if b & 0x80:
                b = ((b & 0x7F) << 8) | data[p]; p += 1
            strings.append(data[p:p + b].decode("utf-8", errors="replace"))
        else:
            n = struct.unpack_from("<H", data, p)[0]; p += 2
            if n & 0x8000:
                n = ((n & 0x7FFF) << 16) | struct.unpack_from("<H", data, p)[0]; p += 2
            strings.append(data[p:p + n * 2].decode("utf-16-le", errors="replace"))
    return strings


def parse_manifest_axml(data: bytes) -> dict:
    """Trả về dict có thể thiếu khoá nếu APK bị obfuscate tên thuộc tính. Không bao giờ ném lỗi."""
    info: dict = {}
    try:
        if struct.unpack_from("<H", data, 0)[0] != 0x0003:
            return info
        pos, strings = 8, []
        while pos + 8 <= len(data):
            ctype, _hs, size = struct.unpack_from("<HHI", data, pos)
            if size < 8 or pos + size > len(data):
                break
            if ctype == 0x0001:
                strings = _read_string_pool(data, pos)
            elif ctype == 0x0102:
                _ns, name_i, attr_start, attr_size, attr_count = struct.unpack_from("<IIHHH", data, pos + 16)
                element = strings[name_i] if name_i < len(strings) else ""
                if element in ("manifest", "application"):
                    base = pos + 16 + attr_start
                    for k in range(attr_count):
                        _n, attr_name, raw, _sz, _r0, dtype, value = struct.unpack_from("<IIIHBBI", data, base + k * attr_size)
                        key = strings[attr_name] if attr_name < len(strings) else ""
                        if dtype == 0x03:
                            parsed = strings[value] if value < len(strings) else None
                        elif dtype in (0x10, 0x11):
                            parsed = value
                        elif dtype == 0x12:
                            parsed = value != 0
                        else:
                            continue
                        if element == "manifest" and key in ("package", "versionName", "versionCode"):
                            info[key] = parsed
                        elif element == "application" and key == "debuggable":
                            info["debuggable"] = parsed
                    if element == "application":
                        break
            pos += size
    except (struct.error, IndexError, UnicodeDecodeError):
        pass
    return info


def _has_v2_block(path: Path) -> bool:
    try:
        with open(path, "rb") as fh:
            fh.seek(0, os.SEEK_END)
            end = fh.tell()
            tail_len = min(end, 65557)
            fh.seek(end - tail_len)
            tail = fh.read(tail_len)
            i = tail.rfind(b"PK\x05\x06")
            if i < 0 or i + 20 > len(tail):
                return False
            cd_offset = struct.unpack_from("<I", tail, i + 16)[0]
            if cd_offset < 16:
                return False
            fh.seek(cd_offset - 16)
            return fh.read(16) == b"APK Sig Block 42"
    except OSError:
        return False


def validate_apk(path: Path | str) -> ApkReport:
    path = Path(path)

    def bad(msg: str) -> EngineError:
        return EngineError(ErrorCode.APK_VALIDATION_ERROR, msg,
                           hint="Xem logs build; APK sinh ra không đạt kiểm tra cấu trúc.")

    if not path.is_file():
        raise bad("File APK không tồn tại.")
    size = path.stat().st_size
    if size == 0:
        raise bad("File APK rỗng.")
    if not zipfile.is_zipfile(path):
        raise bad("APK không phải file ZIP hợp lệ.")
    try:
        with zipfile.ZipFile(path) as zf:
            broken = zf.testzip()
            if broken:
                raise bad(f"APK bị hỏng (CRC sai ở {broken}).")
            names = set(zf.namelist())
            if "AndroidManifest.xml" not in names:
                raise bad("APK thiếu AndroidManifest.xml.")
            manifest_info = zf.getinfo("AndroidManifest.xml")
            manifest = zf.read("AndroidManifest.xml") if manifest_info.file_size <= _MAX_MANIFEST else b""
            v1 = any(n.startswith("META-INF/") and n.upper().endswith((".RSA", ".DSA", ".EC")) for n in names)
    except (zipfile.BadZipFile, OSError) as exc:
        raise bad(f"Không đọc được APK: {exc}") from None
    report = ApkReport(path=path, size=size, sha256=sha256_file(path),
                       has_classes_dex="classes.dex" in names,
                       signature_present=v1 or _has_v2_block(path))
    parsed = parse_manifest_axml(manifest)
    report.package_name = parsed.get("package")
    report.version_name = parsed.get("versionName")
    report.version_code = parsed.get("versionCode")
    report.debuggable = parsed.get("debuggable")
    meta = path.parent / "output-metadata.json"
    if meta.is_file() and not (report.package_name and report.version_code is not None):
        try:
            data = json.loads(meta.read_text(encoding="utf-8"))
            report.package_name = report.package_name or data.get("applicationId")
            elements = data.get("elements") or [{}]
            report.version_name = report.version_name or elements[0].get("versionName")
            if report.version_code is None:
                report.version_code = elements[0].get("versionCode")
        except (ValueError, OSError):
            pass
    if not report.has_classes_dex:
        report.warnings.append("APK không có classes.dex.")
    if not report.signature_present:
        report.warnings.append("APK chưa được ký nên không cài đặt được trên thiết bị (thường gặp ở bản release "
                               "khi dự án chưa cấu hình signing).")
    return report
