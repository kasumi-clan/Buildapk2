"""Kiểm tra và giải nén ZIP an toàn (chống path traversal, symlink, ZIP bomb, timeout)."""
from __future__ import annotations

import hashlib
import hmac
import os
import posixpath
import re
import stat
import time
import zipfile
import zlib
from dataclasses import dataclass, field
from pathlib import Path

from config import Config, MB
from errors import EngineError, ErrorCode

_DRIVE_RE = re.compile(r"^[A-Za-z]:")
_JUNK_NAMES = {".DS_Store", "Thumbs.db"}
_CHUNK = 1024 * 1024


def sha256_file(path: Path | str, chunk_size: int = _CHUNK) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            block = fh.read(chunk_size)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def verify_zip_file(zip_path: Path | str, cfg: Config, expected_sha256: str | None = None) -> str:
    """Kiểm tra tồn tại/dung lượng/checksum/định dạng. Trả về SHA-256 thực tế."""
    path = Path(zip_path)
    if not path.is_file():
        raise EngineError(ErrorCode.INVALID_ZIP, "Không tìm thấy file ZIP.")
    size = path.stat().st_size
    if size == 0:
        raise EngineError(ErrorCode.INVALID_ZIP, "File ZIP rỗng.")
    if size > cfg.max_zip_bytes:
        raise EngineError(ErrorCode.INVALID_ZIP,
                          f"File ZIP lớn hơn giới hạn {cfg.max_zip_bytes // MB} MB.")
    digest = sha256_file(path)
    if expected_sha256:
        expected = expected_sha256.strip().lower()
        if not re.fullmatch(r"[0-9a-f]{64}", expected):
            raise EngineError(ErrorCode.INTERNAL_ERROR, "Checksum SHA-256 mong đợi không đúng định dạng.")
        if not hmac.compare_digest(expected, digest):
            raise EngineError(ErrorCode.STORAGE_ERROR,
                              "SHA-256 của file ZIP không khớp với checksum lúc upload.",
                              hint="File có thể bị lỗi khi lưu/tải về. Hãy upload lại rồi build lại.")
    if not zipfile.is_zipfile(path):
        raise EngineError(ErrorCode.INVALID_ZIP, "File không phải ZIP hợp lệ hoặc đã bị hỏng.",
                          hint="Hãy nén lại thư mục dự án bằng định dạng .zip rồi upload lại.")
    return digest


def _security(message: str, **details) -> EngineError:
    return EngineError(ErrorCode.ZIP_SECURITY_ERROR, message,
                       hint="ZIP chứa nội dung không an toàn nên bị từ chối. Hãy nén lại chỉ source dự án.",
                       details=details)


def normalize_member_name(name: str) -> str:
    """Chuẩn hoá tên entry; ném lỗi nếu có dấu hiệu traversal. Trả về '' nếu entry rỗng."""
    if "\x00" in name:
        raise _security("Tên file trong ZIP chứa ký tự NUL.", entry=name[:200])
    normalized = name.replace("\\", "/")
    if normalized.startswith("/") or _DRIVE_RE.match(normalized):
        raise _security("ZIP chứa đường dẫn tuyệt đối.", entry=name[:200])
    parts = [p for p in normalized.split("/") if p not in ("", ".")]
    if any(p == ".." for p in parts):
        raise _security("ZIP chứa đường dẫn thoát khỏi thư mục giải nén (path traversal).", entry=name[:200])
    return "/".join(parts)


def _ensure_within(root_real: str, path: str, entry: str) -> None:
    real = os.path.realpath(path)
    if real != root_real and not real.startswith(root_real + os.sep):
        raise _security("Đường dẫn giải nén nằm ngoài thư mục cho phép.", entry=entry[:200])


def _precheck(infos, cfg: Config) -> None:
    if len(infos) > cfg.max_file_count:
        raise _security(f"ZIP có quá nhiều file (giới hạn {cfg.max_file_count}).", count=len(infos))
    total = 0
    for info in infos:
        if len(info.filename) > 1024:
            raise _security("Tên file trong ZIP quá dài.")
        total += info.file_size
        if info.file_size > cfg.max_file_bytes:
            raise _security("Một file trong ZIP vượt giới hạn dung lượng.", entry=info.filename[:200])
        if info.file_size > MB:
            if info.compress_size == 0 or info.file_size / info.compress_size > cfg.max_compression_ratio:
                raise _security("Tỉ lệ nén bất thường (nghi ZIP bomb).", entry=info.filename[:200])
    if total > cfg.max_extracted_bytes:
        raise _security(
            f"Tổng dung lượng sau giải nén vượt giới hạn {cfg.max_extracted_bytes // MB} MB (nghi ZIP bomb).",
            declared_bytes=total)


def _symlink_is_dangerous(zf: zipfile.ZipFile, info: zipfile.ZipInfo, name: str) -> bool:
    if info.file_size > 1024:
        return True
    try:
        target = zf.read(info).decode("utf-8")
    except (UnicodeDecodeError, zipfile.BadZipFile, zlib.error):
        return True
    if not target or "\x00" in target:
        return True
    target = target.replace("\\", "/")
    if target.startswith("/") or _DRIVE_RE.match(target):
        return True
    resolved = posixpath.normpath(posixpath.join(posixpath.dirname(name), target))
    return resolved == ".." or resolved.startswith("../")


@dataclass
class ExtractionReport:
    root: Path
    file_count: int = 0
    total_bytes: int = 0
    skipped: list = field(default_factory=list)
    warnings: list = field(default_factory=list)


def safe_extract(zip_path: Path | str, dest: Path | str, cfg: Config) -> ExtractionReport:
    """Giải nén có giới hạn. Toàn vẹn dữ liệu (CRC) được kiểm tra ngay trong lúc giải nén
    (zipfile ném BadZipFile nếu CRC sai) nên không cần đọc ZIP hai lần."""
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    dest_real = os.path.realpath(dest)
    deadline = time.monotonic() + cfg.extract_timeout_s
    report = ExtractionReport(root=dest)
    try:
        with zipfile.ZipFile(zip_path) as zf:
            infos = zf.infolist()
            _precheck(infos, cfg)
            seen: set = set()
            for info in infos:
                if time.monotonic() > deadline:
                    raise _security("Giải nén quá thời gian cho phép.", timeout_s=cfg.extract_timeout_s)
                name = normalize_member_name(info.filename)
                if not name:
                    continue
                if name.startswith("__MACOSX/") or posixpath.basename(name) in _JUNK_NAMES:
                    report.skipped.append(name)
                    continue
                if info.flag_bits & 0x1:
                    raise EngineError(ErrorCode.INVALID_ZIP, "ZIP có mật khẩu, không được hỗ trợ.")
                mode = (info.external_attr >> 16) if info.create_system == 3 else 0
                ftype = stat.S_IFMT(mode)
                if ftype == stat.S_IFLNK:
                    if _symlink_is_dangerous(zf, info, name):
                        raise _security("ZIP chứa symlink nguy hiểm.", entry=name[:200])
                    report.skipped.append(name)
                    report.warnings.append(f"Bỏ qua symlink: {name}")
                    continue
                if ftype not in (0, stat.S_IFREG, stat.S_IFDIR):
                    raise _security("ZIP chứa loại file đặc biệt không được phép.", entry=name[:200])
                target = os.path.join(dest_real, *name.split("/"))
                _ensure_within(dest_real, os.path.dirname(target), name)
                if info.filename.endswith(("/", "\\")):
                    os.makedirs(target, mode=0o755, exist_ok=True)
                    continue
                if name in seen:
                    raise _security("ZIP có hai entry trùng đường dẫn.", entry=name[:200])
                seen.add(name)
                os.makedirs(os.path.dirname(target), mode=0o755, exist_ok=True)
                flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
                try:
                    fd = os.open(target, flags, 0o600)
                except OSError:
                    raise _security("Xung đột đường dẫn khi giải nén.", entry=name[:200]) from None
                written = 0
                with os.fdopen(fd, "wb") as out, zf.open(info) as src:
                    while True:
                        block = src.read(_CHUNK)
                        if not block:
                            break
                        written += len(block)
                        report.total_bytes += len(block)
                        if written > info.file_size or report.total_bytes > cfg.max_extracted_bytes:
                            raise _security("Dung lượng giải nén thực tế vượt mức khai báo/giới hạn (nghi ZIP bomb).",
                                            entry=name[:200])
                        if time.monotonic() > deadline:
                            raise _security("Giải nén quá thời gian cho phép.", timeout_s=cfg.extract_timeout_s)
                        out.write(block)
                perm = mode & 0o777
                os.chmod(target, 0o755 if perm & 0o111 else 0o644)
                report.file_count += 1
    except zipfile.BadZipFile as exc:
        raise EngineError(ErrorCode.INVALID_ZIP, f"ZIP bị hỏng hoặc sai CRC: {exc}",
                          hint="Hãy nén lại dự án và upload lại.") from None
    except (zlib.error, EOFError, NotImplementedError, RuntimeError) as exc:
        raise EngineError(ErrorCode.INVALID_ZIP, f"Không đọc được dữ liệu nén trong ZIP: {exc}",
                          hint="Hãy nén lại dự án bằng ZIP chuẩn (Deflate) và upload lại.") from None
    return report
