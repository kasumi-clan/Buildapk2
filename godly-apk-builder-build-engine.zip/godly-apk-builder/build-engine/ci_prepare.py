"""Bước chuẩn bị cho GitHub Actions: chọn ZIP DỰ ÁN cần build (bỏ qua ZIP của build engine) và
đọc thông tin Gradle wrapper từ bên trong ZIP mà không giải nén ra đĩa.

Ghi vào $GITHUB_OUTPUT: skip, zip_path, needs_system_gradle, gradle_version."""
from __future__ import annotations

import argparse
import os
import re
import subprocess
import sys
import zipfile

DEFAULT_GRADLE = "8.14.3"
_VERSION_IN_URL = re.compile(r"gradle-(\d+(?:\.\d+){1,2})-(?:bin|all)\.zip")
_PLAIN_VERSION = re.compile(r"^\d+(?:\.\d+){1,2}$")


def is_engine_zip(path: str) -> bool:
    return "build-engine" in os.path.basename(path).lower()


def _git(repo: str, *args: str) -> list:
    try:
        out = subprocess.run(["git", "-c", "core.quotepath=off", *args], cwd=repo, capture_output=True,
                             text=True, timeout=60, check=True).stdout
    except (OSError, subprocess.SubprocessError):
        return []
    return [line for line in out.splitlines() if line.strip()]


def _valid_candidate(repo: str, rel: str) -> bool:
    return (rel.lower().endswith(".zip") and not is_engine_zip(rel) and not rel.startswith(".github/")
            and not any(ord(c) < 32 for c in rel) and os.path.isfile(os.path.join(repo, rel)))


def resolve_requested(repo: str, requested: str) -> str:
    rel = os.path.normpath(requested.strip().replace("\\", "/")).lstrip("/")
    if not rel.lower().endswith(".zip") or rel.startswith("..") or any(ord(c) < 32 for c in rel):
        raise ValueError("Đường dẫn ZIP không hợp lệ (phải là file .zip nằm trong repo).")
    repo_real = os.path.realpath(repo)
    full = os.path.realpath(os.path.join(repo, rel))
    if not full.startswith(repo_real + os.sep) or not os.path.isfile(full):
        raise ValueError(f"Không thấy file '{requested}' trong repo.")
    if is_engine_zip(rel):
        raise ValueError("Đây là file build engine, không phải dự án Android. Hãy chọn ZIP dự án.")
    return os.path.relpath(full, repo_real)


def _newest_first(repo: str, paths: list) -> list:
    def stamp(p: str) -> float:
        out = _git(repo, "log", "-1", "--format=%ct", "--", p)
        return float(out[0]) if out else os.path.getmtime(os.path.join(repo, p))
    return sorted(paths, key=lambda p: (-stamp(p), p))


def choose_zip(repo: str, event: str, requested: str = "") -> tuple:
    """Trả về (zip_tương_đối | None, ghi_chú). None nghĩa là không có gì để build (chỉ với sự kiện push)."""
    notes: list = []
    if requested.strip():
        return resolve_requested(repo, requested), notes
    if event == "push":
        changed = [p for p in _git(repo, "show", "--name-only", "--pretty=format:", "HEAD") if _valid_candidate(repo, p)]
        if not changed:
            notes.append("Commit này không thêm/sửa ZIP dự án nào; bỏ qua build.")
            return None, notes
        changed = _newest_first(repo, changed)
        if len(changed) > 1:
            notes.append("Commit có nhiều ZIP dự án; chỉ build file đầu tiên: " + changed[0]
                         + ". Các file khác: " + ", ".join(changed[1:]))
        return changed[0], notes
    tracked = [p for p in _git(repo, "ls-files", "*.zip") if _valid_candidate(repo, p)]
    if not tracked:  # không có git (hoặc chưa commit): quét thư mục
        for dirpath, dirnames, filenames in os.walk(repo):
            dirnames[:] = [d for d in dirnames if d != ".git"]
            for name in filenames:
                rel = os.path.relpath(os.path.join(dirpath, name), repo)
                if _valid_candidate(repo, rel):
                    tracked.append(rel)
    if not tracked:
        raise ValueError("Không thấy ZIP dự án nào trong repo (ZIP của build engine không tính). "
                         "Hãy upload ZIP dự án Android lên repo.")
    tracked = _newest_first(repo, tracked)
    if len(tracked) > 1:
        notes.append("Có nhiều ZIP dự án; chọn file mới nhất: " + tracked[0])
    return tracked[0], notes


def inspect_wrapper(zip_path: str) -> dict:
    """Đọc danh sách entry + file gradle-wrapper.properties (tối đa 64 KB). Không giải nén ra đĩa."""
    if not zipfile.is_zipfile(zip_path):
        raise ValueError("File không phải ZIP hợp lệ hoặc bị hỏng.")
    with zipfile.ZipFile(zip_path) as z:
        names = [n.replace("\\", "/") for n in z.namelist()]
        marker = "gradle/wrapper/gradle-wrapper.properties"
        props = sorted((n for n in names if n.endswith(marker) and n.count("/") <= 4), key=lambda n: (n.count("/"), n))
        version = None
        if props:
            prefix = props[0][:-len(marker)]
            has_jar = (prefix + "gradle/wrapper/gradle-wrapper.jar") in names
            has_script = (prefix + "gradlew") in names
            info = next(i for i in z.infolist() if i.filename.replace("\\", "/") == props[0])
            if info.file_size <= 65536:
                text = z.read(info).decode("utf-8", errors="replace").replace("\\:", ":")
                m = _VERSION_IN_URL.search(text)
                version = m.group(1) if m else None
        else:
            has_jar = False
            has_script = any(n == "gradlew" or (n.count("/") <= 1 and n.endswith("/gradlew")) for n in names)
    return {"has_properties": bool(props), "has_jar": has_jar, "has_script": has_script, "gradle_version": version,
            "needs_system_gradle": not (props and has_jar and has_script)}


def write_outputs(path: str | None, values: dict) -> None:
    for k, v in values.items():
        if any(ord(c) < 32 for c in str(v)):
            raise ValueError(f"Giá trị output '{k}' chứa ký tự điều khiển.")
    lines = "".join(f"{k}={v}\n" for k, v in values.items())
    if path:
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(lines)
    else:
        print(lines, end="")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--event", default="workflow_dispatch")
    ap.add_argument("--zip", default="")
    ap.add_argument("--default-gradle", default=DEFAULT_GRADLE)
    ns = ap.parse_args(argv)
    out_file = os.environ.get("GITHUB_OUTPUT")
    try:
        chosen, notes = choose_zip(ns.repo, ns.event, ns.zip)
        for note in notes:
            print(f"::notice::{note}")
        if chosen is None:
            write_outputs(out_file, {"skip": "true"})
            return 0
        info = inspect_wrapper(os.path.join(ns.repo, chosen))
    except ValueError as exc:
        print(f"::error title=Không chọn được ZIP::{exc}")
        return 1
    default = ns.default_gradle if _PLAIN_VERSION.match(ns.default_gradle or "") else DEFAULT_GRADLE
    version = info["gradle_version"] if info["gradle_version"] and _PLAIN_VERSION.match(info["gradle_version"]) else default
    print(f"ZIP dự án: {chosen}")
    if info["needs_system_gradle"]:
        print(f"::notice::ZIP thiếu gradlew/gradle-wrapper.jar; sẽ dùng Gradle {version} cài sẵn trên runner.")
    write_outputs(out_file, {"skip": "false", "zip_path": chosen,
                             "needs_system_gradle": str(info["needs_system_gradle"]).lower(),
                             "gradle_version": version})
    return 0


if __name__ == "__main__":
    sys.exit(main())
