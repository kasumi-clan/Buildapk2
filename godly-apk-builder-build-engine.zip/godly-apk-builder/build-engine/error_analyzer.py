"""Phân loại lỗi build từ log THẬT. Chỉ báo file/dòng khi log có ghi; không suy đoán."""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field

from errors import EngineError, ErrorCode
from logger import redact

UNDETERMINED = "Không thể xác định chính xác nguyên nhân. Vui lòng xem logs đầy đủ."

_CATALOG = {
    ErrorCode.INVALID_ZIP: ("File ZIP không hợp lệ", "Nén lại dự án thành file .zip chuẩn rồi upload lại.", False),
    ErrorCode.ZIP_SECURITY_ERROR: ("ZIP không an toàn", "Nén lại chỉ gồm source dự án, không có symlink/đường dẫn lạ.", False),
    ErrorCode.PROJECT_NOT_FOUND: ("Không tìm thấy dự án Android", "Kiểm tra cấu trúc ZIP (xem gợi ý bên dưới).", False),
    ErrorCode.GRADLE_WRAPPER_MISSING: ("Thiếu hoặc hỏng Gradle wrapper", "Nén kèm gradlew và thư mục gradle/wrapper (có gradle-wrapper.jar).", False),
    ErrorCode.JDK_ERROR: ("Lỗi phiên bản/cấu hình JDK", "Dùng JDK đúng phiên bản dự án yêu cầu (thường JDK 17 cho AGP 8.x).", False),
    ErrorCode.ANDROID_SDK_ERROR: ("Lỗi Android SDK", "Kiểm tra compileSdk/buildTools của dự án có trong SDK của runner và license đã được chấp nhận.", False),
    ErrorCode.DEPENDENCY_DOWNLOAD_ERROR: ("Không tải được dependency", "Kiểm tra tên/phiên bản thư viện và repositories trong build.gradle; thử build lại.", True),
    ErrorCode.NETWORK_ERROR: ("Lỗi mạng khi build", "Thường là lỗi tạm thời của mạng/runner. Thử build lại.", True),
    ErrorCode.JAVA_COMPILATION_ERROR: ("Lỗi biên dịch Java", "Sửa lỗi ở file/dòng được báo rồi nén và upload lại.", False),
    ErrorCode.KOTLIN_COMPILATION_ERROR: ("Lỗi biên dịch Kotlin", "Sửa lỗi ở file/dòng được báo rồi nén và upload lại.", False),
    ErrorCode.RESOURCE_ERROR: ("Lỗi tài nguyên (resources)", "Kiểm tra file XML/tài nguyên được báo (tên, tham chiếu @drawable/@string...).", False),
    ErrorCode.MANIFEST_ERROR: ("Lỗi AndroidManifest", "Kiểm tra AndroidManifest.xml và xung đột manifest giữa các thư viện.", False),
    ErrorCode.GRADLE_CONFIGURATION_ERROR: ("Lỗi cấu hình Gradle", "Kiểm tra build.gradle/settings.gradle, plugin và phiên bản Gradle.", False),
    ErrorCode.APK_NOT_FOUND: ("Build xong nhưng không thấy APK", "Kiểm tra module có tạo APK không và chọn đúng debug/release hoặc flavor.", False),
    ErrorCode.APK_VALIDATION_ERROR: ("APK không đạt kiểm tra", "Xem logs build; thử build lại.", True),
    ErrorCode.BUILD_TIMEOUT: ("Build quá thời gian", "Dự án build quá lâu so với giới hạn. Thử lại hoặc giảm kích thước dự án.", True),
    ErrorCode.BUILD_CANCELLED: ("Build đã bị huỷ", "Bạn có thể tạo build mới.", True),
    ErrorCode.STORAGE_ERROR: ("Lỗi lưu trữ/checksum", "Upload lại file ZIP rồi build lại.", True),
    ErrorCode.GITHUB_ERROR: ("Lỗi GitHub", "Kiểm tra kết nối GitHub PAT và quyền của token.", True),
    ErrorCode.INTERNAL_ERROR: ("Lỗi nội bộ của build engine", "Xem logs; nếu lặp lại hãy báo cho quản trị viên.", True),
    ErrorCode.UNKNOWN_BUILD_ERROR: ("Build thất bại", "Mở logs đầy đủ để xem chi tiết.", False),
}


@dataclass
class ErrorReport:
    code: str
    title: str
    cause: str
    hint: str
    retryable: bool
    confident: bool
    file: str | None = None
    line: int | None = None
    excerpt: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


def _make(code: ErrorCode, cause: str, *, hint: str | None = None, file=None, line=None,
          excerpt=None, confident=True) -> ErrorReport:
    title, default_hint, retry = _CATALOG[code]
    return ErrorReport(code=code.value, title=title, cause=cause, hint=hint or default_hint,
                       retryable=retry, confident=confident, file=file, line=line, excerpt=excerpt or [])


def from_engine_error(exc: EngineError) -> ErrorReport:
    return _make(exc.code, exc.message, hint=exc.hint)


def timeout_report(seconds: int) -> ErrorReport:
    return _make(ErrorCode.BUILD_TIMEOUT, f"Build vượt quá {seconds} giây và đã bị dừng.")


def cancelled_report() -> ErrorReport:
    return _make(ErrorCode.BUILD_CANCELLED, "Build bị huỷ theo yêu cầu; tiến trình Gradle đã được dừng.")


# ---- quy tắc phân tích ---------------------------------------------------------------------

_KOTLIN_A = re.compile(r"^e: (?:file://)?(?P<file>\S.*?\.kts?):(?P<line>\d+):(?P<col>\d+)\s+(?P<msg>.*)$")
_KOTLIN_B = re.compile(r"^e: (?:file://)?(?P<file>\S.*?\.kts?): \((?P<line>\d+), (?P<col>\d+)\): (?P<msg>.*)$")
_JAVA = re.compile(r"^(?:file://)?(?P<file>\S.*?\.java):(?P<line>\d+): error: (?P<msg>.*)$")
_GROOVY_BUILD = re.compile(r"(?:Build|Settings) file '(?P<file>[^']+)' line: (?P<line>\d+)")
_MANIFEST_LOC = re.compile(r"(?P<file>\S*AndroidManifest\.xml):(?P<line>\d+)")
_RES_LOC = re.compile(r"(?P<file>\S+\.xml):(?P<line>\d+)(?::\d+)?[: ]")

_WRAPPER = [r"gradlew: (?:command )?not found", r"gradlew: No such file or directory",
            r"Could not find or load main class org\.gradle\.wrapper"]
_JDK = [r"Unsupported class file major version \d+", r"JAVA_HOME is not set", r"JAVA_HOME is set to an invalid",
        r"requires Java \d+", r"invalid (?:source|target) release", r"release version \d+ not supported",
        r"incompatible Java", r"Unsupported Java"]
_SDK = [r"SDK location not found", r"Failed to find Build Tools revision", r"Failed to find target with hash string",
        r"Failed to install the following (?:Android )?SDK", r"licenses? (?:for package .* )?(?:have|has) not been accepted",
        r"License for package .* not accepted", r"No version of NDK matched"]
_NETWORK = [r"UnknownHostException", r"Connect(?:ion)? timed out", r"Read timed out", r"SSLHandshakeException",
            r"Connection reset", r"No route to host", r"Network is unreachable", r"Premature end of Content-Length"]
_DEPENDENCY = [r"Could not resolve ", r"Could not find [\w.\-]+:[\w.\-]+:", r"Could not download ",
               r"Could not GET ", r"Plugin .* was not found in any of the following sources"]
_MANIFEST = [r"Manifest merger failed", r"AndroidManifest\.xml.*(?:Error|error)", r"process\w*Manifest.*FAILED"]
_RESOURCE = [r"AAPT: error", r"Android resource (?:linking|compilation) failed", r"error: resource .* not found",
             r"Execution failed for task ':[^']*:(?:process|merge)\w*Resources'"]
_CONFIG = [r"A problem occurred (?:evaluating|configuring)", r"Script compilation error",
           r"Could not compile (?:build|settings) file", r"Could not find method", r"Could not get unknown property",
           r"Plugin with id '[^']+' not found", r"Minimum supported Gradle version", r"Unsupported Gradle"]


def _first(lines: list, patterns: list) -> tuple:
    compiled = [re.compile(p) for p in patterns]
    for i, line in enumerate(lines):
        for rx in compiled:
            if rx.search(line):
                return i, line
    return None, None


def _rel(path: str, prefixes) -> str:
    path = path.replace("file://", "")
    for prefix in prefixes:
        prefix = str(prefix).rstrip("/") + "/"
        if prefix and path.startswith(prefix):
            return path[len(prefix):]
    return path


def _what_went_wrong(lines: list) -> list:
    for i, line in enumerate(lines):
        if line.strip() == "* What went wrong:":
            block = []
            for nxt in lines[i + 1:i + 25]:
                if nxt.startswith("* Try:") or nxt.startswith("* Get more help"):
                    break
                block.append(nxt)
            return block
    return []


def _excerpt(lines: list, idx: int, size: int = 10) -> list:
    return [l[:400] for l in lines[max(0, idx - 1): idx + size]]


def analyze_gradle_log(lines: list, strip_prefixes=()) -> ErrorReport:
    lines = [redact(l) for l in lines]
    wwr = _what_went_wrong(lines)

    def report(code, i, text, **kw):
        return _make(code, kw.pop("cause", None) or text.strip()[:300], excerpt=_excerpt(lines, i), **kw)

    for patterns, code in ((_WRAPPER, ErrorCode.GRADLE_WRAPPER_MISSING), (_JDK, ErrorCode.JDK_ERROR),
                           (_SDK, ErrorCode.ANDROID_SDK_ERROR), (_NETWORK, ErrorCode.NETWORK_ERROR)):
        i, line = _first(lines, patterns)
        if line is not None:
            return report(code, i, line)

    # Lỗi nằm trong script .gradle.kts là lỗi cấu hình, không phải lỗi biên dịch source.
    for i, line in enumerate(lines):
        m = _KOTLIN_A.match(line) or _KOTLIN_B.match(line)
        if m:
            file = _rel(m["file"], strip_prefixes)
            if file.endswith(".gradle.kts"):
                return report(ErrorCode.GRADLE_CONFIGURATION_ERROR, i, line, cause=m["msg"][:300],
                              file=file, line=int(m["line"]))
            return report(ErrorCode.KOTLIN_COMPILATION_ERROR, i, line, cause=m["msg"][:300],
                          file=file, line=int(m["line"]))
    for i, line in enumerate(lines):
        m = _JAVA.match(line)
        if m:
            return report(ErrorCode.JAVA_COMPILATION_ERROR, i, line, cause=m["msg"][:300],
                          file=_rel(m["file"], strip_prefixes), line=int(m["line"]))

    i, line = _first(lines, _MANIFEST)
    if line is not None:
        loc = next((_MANIFEST_LOC.search(l) for l in lines if _MANIFEST_LOC.search(l)), None)
        return report(ErrorCode.MANIFEST_ERROR, i, line,
                      file=_rel(loc["file"], strip_prefixes) if loc else None, line=int(loc["line"]) if loc else None)
    i, line = _first(lines, _RESOURCE)
    if line is not None:
        loc = next((_RES_LOC.search(l) for l in lines if "error" in l.lower() and _RES_LOC.search(l)), None)
        return report(ErrorCode.RESOURCE_ERROR, i, line,
                      file=_rel(loc["file"], strip_prefixes) if loc else None, line=int(loc["line"]) if loc else None)
    i, line = _first(lines, _DEPENDENCY)
    if line is not None:
        return report(ErrorCode.DEPENDENCY_DOWNLOAD_ERROR, i, line)
    i, line = _first(lines, _CONFIG)
    if line is not None:
        loc = next((_GROOVY_BUILD.search(l) for l in lines if _GROOVY_BUILD.search(l)), None)
        return report(ErrorCode.GRADLE_CONFIGURATION_ERROR, i, line,
                      file=_rel(loc["file"], strip_prefixes) if loc else None, line=int(loc["line"]) if loc else None)

    excerpt = [l[:400] for l in wwr] or [l[:400] for l in lines[-15:]]
    return _make(ErrorCode.UNKNOWN_BUILD_ERROR, UNDETERMINED, excerpt=excerpt, confident=False)
