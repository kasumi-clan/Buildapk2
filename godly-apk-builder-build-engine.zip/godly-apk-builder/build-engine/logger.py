"""Log có che secret, tail cho error analyzer, và status.json ghi nguyên tử."""
from __future__ import annotations

import json
import os
import re
import threading
from collections import deque
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path


class Status(str, Enum):
    QUEUED = "QUEUED"
    UPLOADING = "UPLOADING"
    EXTRACTING = "EXTRACTING"
    VALIDATING = "VALIDATING"
    CONFIGURING = "CONFIGURING"
    BUILDING = "BUILDING"
    PACKAGING = "PACKAGING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    CANCEL_REQUESTED = "CANCEL_REQUESTED"
    CANCELLED = "CANCELLED"
    TIMEOUT = "TIMEOUT"


_R = "[REDACTED]"
_PATTERNS = [
    (re.compile(r"github_pat_[A-Za-z0-9_]{20,}"), _R),
    (re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}"), _R),
    (re.compile(r"(?i)(authorization:\s*(?:bearer|basic|token)\s+)\S+"), r"\1" + _R),
    (re.compile(r"(?i)(https?://)[^/\s:@]+:[^/\s@]+@"), r"\1" + _R + "@"),
    (re.compile(r"(?i)(X-Amz-(?:Signature|Credential|Security-Token)=)[^&\s]+"), r"\1" + _R),
    (re.compile(r"(?i)(\b[A-Z0-9_]*(?:TOKEN|SECRET|PASSWORD|PASSWD|API_?KEY|PRIVATE_KEY|ACCESS_KEY)"
                r"[A-Z0-9_]*\s*[=:]\s*)\S+"), r"\1" + _R),
]


def redact(text: str, extra_secrets: tuple | list = ()) -> str:
    for pattern, repl in _PATTERNS:
        text = pattern.sub(repl, text)
    for secret in extra_secrets:
        if secret and len(secret) >= 6:
            text = text.replace(secret, _R)
    return text


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def write_json_atomic(path: Path | str, data: dict) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


class BuildLogger:
    def __init__(self, log_path: Path | str, *, secrets=(), echo: bool = False,
                 max_bytes: int = 20 * 1024 * 1024, tail_lines: int = 3000):
        self.path = Path(log_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = open(self.path, "a", encoding="utf-8")
        self._lock = threading.Lock()
        self._secrets = [s for s in secrets if s and len(s) >= 6]
        self._echo = echo
        self._max = max_bytes
        self._written = 0
        self._dropped = 0
        self._tail: deque = deque(maxlen=tail_lines)
        self.stage = "INIT"

    def set_stage(self, stage) -> None:
        self.stage = stage.value if isinstance(stage, Status) else str(stage)

    def redact(self, text: str) -> str:
        return redact(text, self._secrets)

    def log(self, message, level: str = "INFO") -> None:
        text = self.redact(str(message))
        for line in (text.splitlines() or [""]):
            with self._lock:
                self._tail.append(line)
                out = f"{now_iso()} [{self.stage}] {level} {line}\n"
                if self._written + len(out) <= self._max:
                    self._fh.write(out)
                    self._fh.flush()
                    self._written += len(out)
                else:
                    if self._dropped == 0:
                        self._fh.write(f"{now_iso()} [LOG] WARN Log đạt giới hạn dung lượng, phần sau bị cắt.\n")
                        self._fh.flush()
                    self._dropped += 1
                if self._echo:
                    print(out, end="")

    def info(self, message): self.log(message, "INFO")
    def warn(self, message): self.log(message, "WARN")
    def error(self, message): self.log(message, "ERROR")

    def tail(self) -> list:
        with self._lock:
            return list(self._tail)

    def close(self) -> None:
        with self._lock:
            if not self._fh.closed:
                self._fh.close()


class StatusReporter:
    """Ghi status.json mỗi khi đổi giai đoạn. Không có % giả: chỉ có giai đoạn thật."""

    def __init__(self, path: Path | str):
        self.path = Path(path)
        self.history: list = []

    def update(self, status: Status, message: str = "", **extra) -> None:
        entry = {"status": status.value, "message": message, "at": now_iso()}
        self.history.append(entry)
        payload = {"status": status.value, "message": message, "updated_at": entry["at"],
                   "history": self.history, **extra}
        write_json_atomic(self.path, payload)
