"""Tìm thư mục gốc dự án Android trong thư mục đã giải nén và phân tích cấu trúc Gradle."""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path

from errors import EngineError, ErrorCode, STRUCTURE_HINT

SETTINGS_NAMES = ("settings.gradle.kts", "settings.gradle")
BUILD_NAMES = ("build.gradle.kts", "build.gradle")
_SKIP_DIRS = {"__MACOSX", ".git", "node_modules", "build", ".gradle", ".idea"}
_PLUGIN_WORD = re.compile(r"\b(?:id|plugin|plugins|apply|alias)\b", re.I)
_APP_RE = re.compile(r"com\.android\.application|android[._-]?application", re.I)
_LIB_RE = re.compile(r"com\.android\.library|android[._-]?library", re.I)
_INCLUDE_RE = re.compile(r"\binclude\s*\(?\s*((?:[\"'][^\"']+[\"']\s*,?\s*)+)\)?")
_PROJECTDIR_RE = re.compile(
    r"project\(\s*[\"'](:[^\"']+)[\"']\s*\)\.projectDir\s*=\s*(?:new\s+)?(?:file|File)\(\s*"
    r"(?:rootDir\s*,\s*)?[\"']([^\"']+)[\"']")
_MAX_READ = 1024 * 1024


@dataclass
class ModuleInfo:
    gradle_path: str
    directory: Path
    build_file: Path | None
    is_application: bool = False
    is_library: bool = False
    flavors: list = field(default_factory=list)


@dataclass
class ProjectInfo:
    root: Path
    dsl: str
    settings_file: Path | None
    has_wrapper_script: bool
    has_wrapper_properties: bool
    has_wrapper_jar: bool
    modules: list = field(default_factory=list)
    warnings: list = field(default_factory=list)

    @property
    def application_modules(self) -> list:
        return [m for m in self.modules if m.is_application]


def _read(path: Path) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read(_MAX_READ)
    except OSError:
        return ""


def _strip_comments(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    return re.sub(r"(?m)(^|\s)//.*$", r"\1", text)


def _first_existing(directory: Path, names) -> Path | None:
    for name in names:
        candidate = directory / name
        if candidate.is_file():
            return candidate
    return None


def has_plugin(text: str, regex: re.Pattern) -> bool:
    for line in _strip_comments(text).splitlines():
        if regex.search(line) and _PLUGIN_WORD.search(line) and not re.search(r"apply\s+false", line):
            return True
    return False


def _extract_flavors(text: str) -> list:
    """Best-effort: đọc tên product flavor bằng cách đếm ngoặc. Không thay thế Gradle."""
    m = re.search(r"\bproductFlavors\s*\{", text)
    if not m:
        return []
    depth, i = 1, m.end()
    while i < len(text) and depth:
        depth += (text[i] == "{") - (text[i] == "}")
        i += 1
    block = text[m.end():i - 1]
    headers, depth, start = [], 0, 0
    for idx, ch in enumerate(block):
        if ch == "{":
            if depth == 0:
                headers.append(block[start:idx])
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                start = idx + 1
        elif ch in "\n;" and depth == 0:
            start = idx + 1
    names: list = []
    for header in headers:
        quoted = re.findall(r"[\"']([A-Za-z_]\w*)[\"']", header)
        words = re.findall(r"[A-Za-z_]\w*", header)
        pick = quoted[-1] if quoted else (words[-1] if words else None)
        if pick and pick not in names:
            names.append(pick)
    return names


def find_project_root(base: Path | str, max_depth: int = 6) -> tuple:
    """Trả về (root, warnings). Ném PROJECT_NOT_FOUND nếu không có dự án Gradle/Android."""
    base = Path(base)
    candidates: list = []
    fallback: list = []
    for dirpath, dirnames, filenames in os.walk(base):
        depth = len(Path(dirpath).relative_to(base).parts)
        dirnames[:] = sorted(d for d in dirnames if d not in _SKIP_DIRS)
        if depth >= max_depth:
            dirnames[:] = []
        here = Path(dirpath)
        names = set(filenames)
        if names & set(SETTINGS_NAMES):
            candidates.append((depth, here))
        else:
            build = _first_existing(here, BUILD_NAMES)
            if build and has_plugin(_read(build), _APP_RE):
                fallback.append((depth, here))
    warnings: list = []
    pool = candidates
    if not pool and fallback:
        pool = fallback
        warnings.append("Không có settings.gradle; dùng build.gradle có plugin com.android.application.")
    if not pool:
        raise EngineError(
            ErrorCode.PROJECT_NOT_FOUND,
            "Không tìm thấy dự án Android/Gradle trong file ZIP (thiếu settings.gradle hoặc build.gradle).",
            hint=STRUCTURE_HINT)
    pool.sort(key=lambda item: (item[0], not (item[1] / "gradlew").is_file(), str(item[1])))
    best_depth = pool[0][0]
    ties = [p for d, p in pool if d == best_depth]
    if len(ties) > 1:
        rel = ", ".join(str(p.relative_to(base)) or "." for p in ties)
        warnings.append(f"Có nhiều thư mục dự án cùng cấp ({rel}); chọn '{ties[0].relative_to(base) or '.'}'.")
    return pool[0][1], warnings


def analyze_project(root: Path | str, warnings: list | None = None) -> ProjectInfo:
    root = Path(root)
    settings = _first_existing(root, SETTINGS_NAMES)
    root_build = _first_existing(root, BUILD_NAMES)
    marker = settings or root_build
    dsl = "kotlin" if marker and marker.name.endswith(".kts") else ("groovy" if marker else "unknown")
    wrapper = root / "gradle" / "wrapper"
    info = ProjectInfo(
        root=root, dsl=dsl, settings_file=settings,
        has_wrapper_script=(root / "gradlew").is_file(),
        has_wrapper_properties=(wrapper / "gradle-wrapper.properties").is_file(),
        has_wrapper_jar=(wrapper / "gradle-wrapper.jar").is_file(),
        warnings=list(warnings or []),
    )
    module_dirs: dict = {}
    if settings:
        text = _strip_comments(_read(settings))
        custom = {p: d for p, d in _PROJECTDIR_RE.findall(text)}
        for group in _INCLUDE_RE.findall(text):
            for raw in re.findall(r"[\"']([^\"']+)[\"']", group):
                path = raw if raw.startswith(":") else ":" + raw
                rel = custom.get(path) or path.strip(":").replace(":", "/")
                module_dirs.setdefault(path, root / rel)
    module_dirs.setdefault(":", root)
    for gradle_path, directory in module_dirs.items():
        resolved = os.path.realpath(directory)
        if not (resolved == os.path.realpath(root) or resolved.startswith(os.path.realpath(root) + os.sep)):
            info.warnings.append(f"Bỏ qua module {gradle_path}: thư mục nằm ngoài dự án.")
            continue
        if not directory.is_dir():
            info.warnings.append(f"Module {gradle_path} khai báo trong settings nhưng không có thư mục {directory.name}.")
            continue
        build = _first_existing(directory, BUILD_NAMES)
        text = _read(build) if build else ""
        info.modules.append(ModuleInfo(
            gradle_path=gradle_path, directory=directory, build_file=build,
            is_application=has_plugin(text, _APP_RE), is_library=has_plugin(text, _LIB_RE),
            flavors=_extract_flavors(_strip_comments(text))))
    return info


def detect_project(extract_dir: Path | str, max_depth: int = 6) -> ProjectInfo:
    root, warnings = find_project_root(extract_dir, max_depth)
    return analyze_project(root, warnings)
